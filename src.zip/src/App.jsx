import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";

import ProtectedRoute from "./components/ProtectedRoute";
import { ROLE_DASHBOARD_MAP, useAuth } from "./context/useAuth";
import LandingPage from "./pages/LandingPage";
import AccountProfile from "./pages/AccountProfile";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/customer/Dashboard";
import MyHome from "./pages/customer/MyHome";
import ReportProblem from "./pages/customer/ReportProblem";
import AIAssessment from "./pages/customer/AIAssessment";
import Professionals from "./pages/customer/Professionals";
import ProfessionalDetails from "./pages/customer/ProfessionalDetails";
import Bookings from "./pages/customer/Bookings";
import BookingDetails from "./pages/customer/BookingDetails";
import Maintenance from "./pages/customer/Maintenance";
import ServiceHistory from "./pages/customer/ServiceHistory";
import HomePassport from "./pages/customer/HomePassport";
import Warranty from "./pages/customer/Warranty";
import Notifications from "./pages/customer/Notifications";
import Emergency from "./pages/customer/Emergency";
import NotFound from "./pages/NotFound";
import ProfessionalDashboard from "./pages/professional/ProfessionalDashboard";
import ProfessionalJobs from "./pages/professional/ProfessionalJobs";
import ProfessionalJobDetails from "./pages/professional/ProfessionalJobDetails";
import ProfessionalProfile from "./pages/professional/ProfessionalProfile";
import ProfessionalAvailability from "./pages/professional/ProfessionalAvailability";
import ProfessionalEarnings from "./pages/professional/ProfessionalEarnings";
import ProfessionalReviews from "./pages/professional/ProfessionalReviews";
import ProfessionalNotifications from "./pages/professional/ProfessionalNotifications";
import ProfessionalApplication from "./pages/professional/ProfessionalApplication";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminProfessionals from "./pages/admin/AdminProfessionals";
import AdminBookings from "./pages/admin/AdminBookings";
import AdminCategories from "./pages/admin/AdminCategories";
import AdminComplaints from "./pages/admin/AdminComplaints";
import AdminWarranties from "./pages/admin/AdminWarranties";
import AdminMaintenance from "./pages/admin/AdminMaintenance";
import AdminAISettings from "./pages/admin/AdminAISettings";
import AdminAnalytics from "./pages/admin/AdminAnalytics";
import EvaluationReport from "./pages/admin/EvaluationReport";
import AdminAuditLogs from "./pages/admin/AdminAuditLogs";
import AdminKnowledgeBase from "./pages/admin/AdminKnowledgeBase";

function App() {
  const { user } = useAuth();

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            user ? (
              <Navigate to={ROLE_DASHBOARD_MAP[user.role] || "/dashboard"} replace />
            ) : (
              <LandingPage />
            )
          }
        />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route element={<ProtectedRoute roles={["customer"]} />}>
          <Route path="/profile" element={<AccountProfile />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/my-home" element={<MyHome />} />
          <Route path="/report-problem" element={<ReportProblem />} />
          <Route path="/ai-assessment" element={<AIAssessment />} />
          <Route path="/professionals" element={<Professionals />} />
          <Route path="/professionals/:id" element={<ProfessionalDetails />} />
          <Route path="/bookings" element={<Bookings />} />
          <Route path="/bookings/:id" element={<BookingDetails />} />
          <Route path="/maintenance" element={<Maintenance />} />
          <Route path="/service-history" element={<ServiceHistory />} />
          <Route path="/home-passport" element={<HomePassport />} />
          <Route path="/warranty" element={<Warranty />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/emergency" element={<Emergency />} />
        </Route>

        <Route element={<ProtectedRoute roles={["professional"]} />}>
          <Route path="/professional/application" element={<ProfessionalApplication />} />
          <Route path="/professional/dashboard" element={<ProfessionalDashboard />} />
          <Route path="/professional/jobs" element={<ProfessionalJobs />} />
          <Route path="/professional/jobs/:id" element={<ProfessionalJobDetails />} />
          <Route path="/professional/profile" element={<ProfessionalProfile />} />
          <Route path="/professional/availability" element={<ProfessionalAvailability />} />
          <Route path="/professional/earnings" element={<ProfessionalEarnings />} />
          <Route path="/professional/reviews" element={<ProfessionalReviews />} />
          <Route path="/professional/notifications" element={<ProfessionalNotifications />} />
        </Route>

        <Route element={<ProtectedRoute roles={["admin"]} />}>
          <Route path="/admin/profile" element={<AccountProfile />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/users" element={<AdminUsers />} />
          <Route path="/admin/professionals" element={<AdminProfessionals />} />
          <Route path="/admin/bookings" element={<AdminBookings />} />
          <Route path="/admin/categories" element={<AdminCategories />} />
          <Route path="/admin/complaints" element={<AdminComplaints />} />
          <Route path="/admin/warranties" element={<AdminWarranties />} />
          <Route path="/admin/maintenance" element={<AdminMaintenance />} />
          <Route path="/admin/ai-settings" element={<AdminAISettings />} />
          <Route path="/admin/analytics" element={<AdminAnalytics />} />
          <Route path="/admin/evaluation-report" element={<EvaluationReport />} />
          <Route path="/admin/knowledge-base" element={<AdminKnowledgeBase />} />
          <Route path="/admin/audit-logs" element={<AdminAuditLogs />} />
        </Route>

        <Route path="/not-found" element={<NotFound />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

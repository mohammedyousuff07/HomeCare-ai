import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import "./index.css";
import "./pages/customer/customer-experience.css";
import "./pages/customer/customer-home.css";
import "./professional.css";
import { AuthProvider } from "./context/AuthContext.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <AuthProvider><App /></AuthProvider>
  </StrictMode>
);

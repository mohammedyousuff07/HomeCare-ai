export const professionals = [
  {
    id: 1,
    name: "Raj Kumar",
    skill: "AC & HVAC Specialist",
    rating: 4.8,
    jobs: 342,
    experience: "7 years",
    distance: "2.4 km",
    verified: true,
    onTime: "94%",
    firstFix: "91%",
  },
  {
    id: 2,
    name: "Arun Electricals",
    skill: "Electrical Specialist",
    rating: 4.7,
    jobs: 281,
    experience: "6 years",
    distance: "3.1 km",
    verified: true,
    onTime: "92%",
    firstFix: "89%",
  },
  {
    id: 3,
    name: "Suresh Plumbing",
    skill: "Plumbing Specialist",
    rating: 4.9,
    jobs: 418,
    experience: "9 years",
    distance: "4.2 km",
    verified: true,
    onTime: "96%",
    firstFix: "94%",
  },
];

export const bookings = [
  {
    id: 1,
    service: "AC Service",
    professional: "Raj Kumar",
    date: "Tomorrow",
    time: "10:00 AM",
    status: "CONFIRMED",
    price: "₹499",
  },
  {
    id: 2,
    service: "Water Purifier Service",
    professional: "Suresh Plumbing",
    date: "15 Sep 2026",
    time: "2:00 PM",
    status: "REQUESTED",
    price: "₹399",
  },
];

export const maintenanceTasks = [
  {
    title: "Water Purifier Service",
    category: "Appliance",
    due: "12 days",
    priority: "Medium",
  },
  {
    title: "AC Preventive Service",
    category: "HVAC",
    due: "28 days",
    priority: "Low",
  },
  {
    title: "Electrical Inspection",
    category: "Electrical",
    due: "3 months",
    priority: "Low",
  },
];
import { useContext } from "react";
import { AuthContext, ROLE_DASHBOARD_MAP } from "./AuthContext";

export function useAuth() {
  return useContext(AuthContext);
}

export { ROLE_DASHBOARD_MAP };
import { createContext, useCallback, useEffect, useMemo, useState } from "react";

import { apiService } from "../services/api";

const AuthContext = createContext(null);

const THEME_KEY = "homecare-theme";
function readTheme() {
  const stored = localStorage.getItem(THEME_KEY);
  if (stored === "light" || stored === "dark") return stored;
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export const ROLE_DASHBOARD_MAP = {
  customer: "/dashboard",
  professional: "/professional/dashboard",
  admin: "/admin/dashboard",
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(() => Boolean(localStorage.getItem("homecare-token")));
  const [theme, setTheme] = useState(readTheme);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme;
    localStorage.setItem(THEME_KEY, theme);
  }, [theme]);

  function toggleTheme() { setTheme((current) => current === "dark" ? "light" : "dark"); }

  useEffect(() => {
    const token = localStorage.getItem("homecare-token");
    if (!token) {
      localStorage.removeItem("homecare-user");
      return;
    }
    apiService.get("/auth/me")
      .then(({ data }) => { setUser(data.user); localStorage.setItem("homecare-user", JSON.stringify(data.user)); })
      .catch(() => { localStorage.removeItem("homecare-token"); localStorage.removeItem("homecare-user"); setUser(null); })
      .finally(() => setLoading(false));
  }, []);

  async function login(profile) {
    const { data } = await apiService.post("/auth/login", profile);
    const account = data.user;
    localStorage.setItem("homecare-token", data.token);
    localStorage.setItem("homecare-user", JSON.stringify(account));
    setUser(account);
    return account;
  }

  async function register(profile) {
    const { data } = await apiService.post("/auth/register", profile);
    const account = data.user;
    localStorage.setItem("homecare-token", data.token);
    localStorage.setItem("homecare-user", JSON.stringify(account));
    setUser(account);
    return account;
  }

  const refreshAccount = useCallback(async () => {
    const { data } = await apiService.get("/auth/me");
    setUser(data.user);
    localStorage.setItem("homecare-user", JSON.stringify(data.user));
    return data.user;
  }, []);

  function logout() {
    localStorage.removeItem("homecare-token");
    localStorage.removeItem("homecare-user");
    setUser(null);
  }

  const value = useMemo(
    () => ({
      user,
      loading,
      login,
      register,
      refreshAccount,
      logout,
      isAuthenticated: Boolean(user),
      theme,
      toggleTheme,
    }),
    [user, loading, refreshAccount, theme]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export { AuthContext };

import { useCallback, useEffect, useState } from "react";
import { BarChart3, BriefcaseBusiness, CalendarDays, Users } from "lucide-react";
import { AdminButton, AdminNotice, AdminWorkspace } from "./AdminWorkspace";
import { apiService } from "../../services/api";

function Bars({ items, labelKey, valueKey, empty }) {
  const max = Math.max(...items.map((item) => Number(item[valueKey]) || 0), 1);
  if (!items.length) return <div className="admin-notice">{empty}</div>;
  return <div className="admin-bars">{items.map((item, index) => <div className="admin-bar-row" key={item[labelKey] || index}><div><span>{item[labelKey]}</span><strong>{item[valueKey]}</strong></div><i><b style={{ width: `${Math.max(4, Number(item[valueKey]) / max * 100)}%` }} /></i></div>)}</div>;
}
export default function AdminAnalytics() {
  const [data, setData] = useState({ stats: {}, byCategory: [], byStatus: [], daily: [] });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    setLoading(true);
    try { const { data: result } = await apiService.get("/admin/analytics"); setData(result); setError(""); }
    catch (e) { setError(e.response?.data?.message || "Could not load analytics. Check the API and database connection."); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return <AnalyticsContent data={data} error={error} loading={loading} refresh={refresh} />;
}

function AnalyticsContent({ data, error, loading, refresh }) {
  const maxDaily = Math.max(...data.daily.map((item) => item.count), 1);
  const cards = [["All bookings", data.stats.total, CalendarDays], ["Last 30 days", data.stats.recent, BarChart3], ["Customers", data.stats.customers, Users], ["Professionals", data.stats.professionals, BriefcaseBusiness]];
  return <AdminWorkspace title="Platform analytics" description="Booking and account activity from the MongoDB records. The activity period is the last 30 days." actions={<AdminButton tone="quiet" onClick={refresh}>Refresh data</AdminButton>}>
    {error ? <AdminNotice error={error} /> : <><div className="admin-stats">{cards.map(([title, value, Icon]) => <article className="app-panel admin-stat" key={title}><span><Icon size={18} /></span><div><small>{title}</small><strong>{loading ? "—" : value ?? 0}</strong></div></article>)}</div>
      <div className="admin-dashboard-grid"><section className="app-panel admin-panel"><p className="section-label">Last 30 days</p><h2>Daily booking requests</h2>{loading ? <AdminNotice loading /> : <div className="admin-daily-chart">{data.daily.length ? data.daily.map((item) => <div className="admin-day-bar" key={item.date} title={`${item.date}: ${item.count} bookings`}><b style={{ height: `${Math.max(5, item.count / maxDaily * 100)}%` }} /><small>{new Date(`${item.date}T00:00:00`).toLocaleDateString(undefined, { day: "numeric", month: "short" })}</small></div>) : <div className="admin-notice">No bookings were created in the last 30 days.</div>}</div>}</section>
      <section className="app-panel admin-panel"><p className="section-label">All time</p><h2>Bookings by status</h2>{loading ? <AdminNotice loading /> : <Bars items={data.byStatus} labelKey="status" valueKey="count" empty="No booking activity yet." />}</section></div>
      <section className="app-panel admin-panel admin-analytics-category"><p className="section-label">All time</p><h2>Most requested service categories</h2>{loading ? <AdminNotice loading /> : <Bars items={data.byCategory} labelKey="category" valueKey="count" empty="Category totals will appear after the first booking." />}</section>
      <p className="admin-help admin-source-note">Counts reflect saved app records. “Last 30 days” uses the booking creation date, not the appointment date.</p></>}
  </AdminWorkspace>;
}

import { ArrowRight, BrainCircuit, CircleAlert, CircleCheck, LockKeyhole, ShieldCheck } from "lucide-react";
import { Link } from "react-router-dom";
import { AdminWorkspace } from "./AdminWorkspace";

export default function AdminAISettings() {
  return <AdminWorkspace title="AI assessment settings" description="Review the current assessment capability and the controls needed before connecting a live AI provider.">
    <section className="app-panel admin-ai-status"><span className="admin-ai-mark"><BrainCircuit size={23} /></span><div className="admin-ai-status-copy"><p className="section-label">Current capability</p><h2>Demo assessment only</h2><p>The customer assessment page currently displays a fixed example. It does not send customer data to an AI model or generate a live diagnosis.</p></div><span className="admin-pill pending">Provider not connected</span></section>
    <div className="admin-info-grid">
      <article className="app-panel admin-info-panel"><div className="admin-info-title"><CircleAlert size={18} /><h2>What customers see today</h2></div><ul><li>A sample plumbing issue with a fixed urgency, confidence score, and estimate.</li><li>A visible note explaining that the assessment is not a professional diagnosis.</li><li>No customer photos, messages, or personal information are sent to an AI service.</li></ul></article>
      <article className="app-panel admin-info-panel"><div className="admin-info-title"><ShieldCheck size={18} /><h2>Before enabling live AI</h2></div><ul><li>Connect and secure an AI provider on the server.</li><li>Define which customer data may be sent and how long it is retained.</li><li>Validate safety guidance, confidence thresholds, and service estimates.</li></ul></article>
    </div>
    <section className="app-panel admin-readiness"><div><LockKeyhole size={18} /><div><strong>Live controls are unavailable</strong><p>There is no AI provider or server-side settings endpoint connected in this project yet. Keeping this page read-only avoids implying that a setting is active when it would have no effect.</p></div></div><Link to="/admin/audit-logs">Review admin activity <ArrowRight size={15} /></Link></section>
    <section className="app-panel admin-info-panel"><div className="admin-info-title"><CircleCheck size={18} /><h2>Current safeguards</h2></div><p className="admin-help">The customer-facing example includes a diagnosis disclaimer. For a real integration, keep provider credentials on the server, disclose AI use, and offer a path to human support.</p></section>
  </AdminWorkspace>;
}

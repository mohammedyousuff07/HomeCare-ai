import { useCallback, useEffect, useMemo, useState } from "react";
import { BookOpen, Check, ChevronDown, Code2, LoaderCircle, Plus, RefreshCw, Sparkles, Tags, WandSparkles, X } from "lucide-react";
import { AdminButton, AdminNotice, AdminWorkspace } from "./AdminWorkspace";
import { apiService } from "../../services/api";
import { matchKnowledgeEntry, suggestKnowledgeMetadata } from "../../../shared/knowledgeMatching.js";

const emptyForm = { sourcePath: "", category: "", topic: "", variant: "", description: "", tags: "" };

function tagsForForm(tags) { return String(tags || "").split(",").map((tag) => tag.trim().toLowerCase()).filter(Boolean); }

function KnowledgeReviewCard({ entry, onGenerate, onReview, busy }) {
  const [draft, setDraft] = useState({ topic: entry.topic || "", category: entry.category || "", variant: entry.variant || "", description: entry.description || "", tags: (entry.tags || []).join(", "), candidateOptimalCode: entry.candidate_optimal_code || entry.user_code || "" });
  const save = (action) => onReview(entry.id, { ...draft, tags: tagsForForm(draft.tags), action });
  return <article className="kb-review-card"><div className="kb-review-card-head"><div><span className="kb-status pending">Needs human review</span><h3>{entry.topic}</h3><small>{entry.source_path}</small></div><Code2 size={19} /></div>
    <div className="kb-review-meta"><span>Reference source: <b>{entry.candidate_source === "llm_generated" ? "LLM suggestion" : "User-code fallback"}</b></span><span>Proposed tags: {(entry.tags || []).join(" · ") || "none"}</span></div>
    <p className="kb-generation-note">{entry.generation_note}</p>
    <details className="kb-edit-details"><summary>Edit metadata and reference code <ChevronDown size={14} /></summary><div className="kb-edit-grid">
      <label>Topic<input value={draft.topic} onChange={(event) => setDraft({ ...draft, topic: event.target.value })} /></label>
      <label>Category<input value={draft.category} onChange={(event) => setDraft({ ...draft, category: event.target.value })} /></label>
      <label>Variant<input value={draft.variant} onChange={(event) => setDraft({ ...draft, variant: event.target.value })} /></label>
      <label>Tags <small>comma separated</small><input value={draft.tags} onChange={(event) => setDraft({ ...draft, tags: event.target.value })} /></label>
      <label className="kb-full-row">Description<textarea rows={2} value={draft.description} onChange={(event) => setDraft({ ...draft, description: event.target.value })} /></label>
      <label className="kb-full-row">Optimal/reference code<textarea className="kb-code-input" rows={8} spellCheck="false" value={draft.candidateOptimalCode} onChange={(event) => setDraft({ ...draft, candidateOptimalCode: event.target.value })} /></label>
    </div></details>
    <div className="kb-review-actions"><AdminButton tone="quiet" disabled={busy} onClick={() => onGenerate(entry.id)}><WandSparkles size={14} /> Generate reference</AdminButton><AdminButton tone="quiet" disabled={busy} onClick={() => save("save")}>Save edits</AdminButton><AdminButton tone="danger" disabled={busy} onClick={() => save("reject")}><X size={14} /> Reject</AdminButton><AdminButton disabled={busy} onClick={() => save("approve")}><Check size={14} /> Approve to KB</AdminButton></div>
  </article>;
}

export default function AdminKnowledgeBase() {
  const [report, setReport] = useState(null);
  const [entries, setEntries] = useState([]);
  const [provisionals, setProvisionals] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [query, setQuery] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [busyKey, setBusyKey] = useState("");
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const loadData = useCallback(async () => {
    try {
      const [kbResponse, reportResponse] = await Promise.all([apiService.get("/admin/code-knowledge"), fetch("/evaluation/latest-metrics.json", { cache: "no-store" })]);
      const kbData = kbResponse.data;
      if (!reportResponse.ok) throw new Error("Run the evaluation pipeline to load module suggestions.");
      const latestReport = await reportResponse.json();
      setEntries(kbData.entries || []); setProvisionals(kbData.provisionalEntries || []); setReport(latestReport); setError("");
    } catch (e) { setError(e.response?.data?.message || e.message || "Could not load the knowledge base. Check API and MongoDB."); }
  }, []);

  const refresh = useCallback(async () => { setRefreshing(true); await loadData(); setRefreshing(false); }, [loadData]);
  useEffect(() => {
    let active = true;
    Promise.all([apiService.get("/admin/code-knowledge"), fetch("/evaluation/latest-metrics.json", { cache: "no-store" })])
      .then(async ([kbResponse, reportResponse]) => {
        const kbData = kbResponse.data;
        if (!reportResponse.ok) throw new Error("Run the evaluation pipeline to load module suggestions.");
        const latestReport = await reportResponse.json();
        if (active) { setEntries(kbData.entries || []); setProvisionals(kbData.provisionalEntries || []); setReport(latestReport); }
      })
      .catch((e) => { if (active) setError(e.response?.data?.message || e.message || "Could not load the knowledge base. Check API and MongoDB."); });
    return () => { active = false; };
  }, []);

  const codeModules = useMemo(() => report?.solution_entries || [], [report]);
  const loading = refreshing || (!report && !error);
  const filteredModules = useMemo(() => codeModules.filter((entry) => `${entry.topic} ${entry.category} ${entry.source_path}`.toLowerCase().includes(query.toLowerCase())), [codeModules, query]);
  const candidate = form.sourcePath ? codeModules.find((item) => item.source_path === form.sourcePath) : null;
  const matchedReference = candidate ? matchKnowledgeEntry({ category: candidate.category, topic: candidate.topic, variant: candidate.variant, tags: suggestKnowledgeMetadata({ sourcePath: candidate.source_path, ...candidate }).tags }, entries) : null;

  function chooseModule(sourcePath) {
    const selected = codeModules.find((entry) => entry.source_path === sourcePath);
    if (!selected) { setForm(emptyForm); return; }
    const suggestion = suggestKnowledgeMetadata({ sourcePath: selected.source_path, ...selected });
    setForm({ sourcePath, category: selected.category, topic: suggestion.topic, variant: selected.variant, description: suggestion.description, tags: suggestion.tags.join(", ") });
    setNotice(""); setError("");
  }

  async function addProvisional(event) {
    event.preventDefault(); if (!form.sourcePath) return;
    setBusyKey("new"); setNotice(""); setError("");
    try {
      const { data } = await apiService.post("/admin/code-knowledge/provisionals", { ...form, tags: tagsForForm(form.tags), metrics: candidate?.metrics || {} });
      setNotice(data.alreadyPending ? "This module is already waiting for review." : "Added as a provisional entry. An admin must review and approve it before it becomes an optimal reference.");
      await refresh();
    } catch (e) { setError(e.response?.data?.message || "Could not add this provisional entry."); }
    finally { setBusyKey(""); }
  }

  async function generate(entryId) {
    setBusyKey(entryId); setNotice(""); setError("");
    try { const { data } = await apiService.post(`/admin/code-knowledge/provisionals/${entryId}/generate`, {}); setNotice(data.message); await refresh(); }
    catch (e) { setError(e.response?.data?.message || "Could not generate a reference suggestion."); }
    finally { setBusyKey(""); }
  }

  async function review(entryId, updates) {
    setBusyKey(entryId); setNotice(""); setError("");
    try { const { data } = await apiService.patch(`/admin/code-knowledge/provisionals/${entryId}`, updates); setNotice(data.message); await refresh(); }
    catch (e) { setError(e.response?.data?.message || "Could not save this review."); }
    finally { setBusyKey(""); }
  }

  return <AdminWorkspace title="Code knowledge base" description="Match HomeCare modules to reviewed reference code. New topics stay provisional until an admin reviews them." actions={<AdminButton tone="quiet" disabled={loading} onClick={refresh}><RefreshCw size={14} /> Refresh</AdminButton>}>
    {notice && <div className="kb-feedback success" role="status">{notice}</div>}{error && <AdminNotice error={error} />}
    <div className="kb-summary-grid"><article className="app-panel kb-summary-card"><span><BookOpen size={18} /></span><div><small>Approved references</small><strong>{entries.length}</strong></div></article><article className="app-panel kb-summary-card"><span><LoaderCircle size={18} /></span><div><small>Awaiting review</small><strong>{provisionals.filter((item) => item.status === "pending_review").length}</strong></div></article><article className="app-panel kb-summary-card"><span><Tags size={18} /></span><div><small>Scanned modules</small><strong>{codeModules.length}</strong></div></article></div>
    <section className="app-panel kb-add-panel"><div className="kb-section-heading"><div><p className="section-label">UNSEEN TOPIC</p><h2>Add a provisional knowledge entry</h2><p>Choose a module. Description and tags are suggested automatically, then you can edit them.</p></div><Sparkles size={20} /></div>
      {loading && !report ? <AdminNotice loading /> : <form className="kb-add-form" onSubmit={addProvisional}>
        <label className="kb-full-row">Search a project module<input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search topic or file path" /></label>
        <label className="kb-full-row">Module<select required value={form.sourcePath} onChange={(event) => chooseModule(event.target.value)}><option value="">Choose a JavaScript/JSX module</option>{filteredModules.map((entry) => <option value={entry.source_path} key={entry.source_path}>{entry.category} · {entry.topic} · {entry.source_path}</option>)}</select></label>
        <label>Category<input value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })} /></label><label>Topic<input value={form.topic} onChange={(event) => setForm({ ...form, topic: event.target.value })} /></label><label>Variant<input value={form.variant} onChange={(event) => setForm({ ...form, variant: event.target.value })} /></label><label>Tags <small>comma separated</small><input value={form.tags} onChange={(event) => setForm({ ...form, tags: event.target.value })} /></label>
        <label className="kb-full-row">Suggested description<textarea rows={3} value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} /></label>
        {candidate && <div className="kb-match-callout kb-full-row">{matchedReference ? <><Check size={16} /><span>Likely KB match: <b>{matchedReference.entry.topic}</b> · {Math.round(matchedReference.score * 100)}% match. Review it before adding a separate entry.</span></> : <><Plus size={16} /><span>No approved reference matched. The module’s own source will be used as a fallback until a human-approved reference is added.</span></>}</div>}
        <div className="kb-form-footer kb-full-row"><span>New entries are private to admins and remain pending until review.</span><AdminButton type="submit" disabled={!form.sourcePath || busyKey === "new" || Boolean(matchedReference)}>{busyKey === "new" ? "Adding…" : <><Plus size={14} /> Add to review queue</>}</AdminButton></div>
      </form>}
    </section>
    <section className="kb-review-section"><div className="kb-section-heading"><div><p className="section-label">HUMAN REVIEW</p><h2>Provisional entries</h2></div></div>{loading ? <AdminNotice loading /> : provisionals.filter((item) => item.status === "pending_review").length ? <div className="kb-review-list">{provisionals.filter((item) => item.status === "pending_review").map((entry) => <KnowledgeReviewCard key={`${entry.id}-${entry.updated_at}`} entry={entry} busy={busyKey === entry.id} onGenerate={generate} onReview={review} />)}</div> : <div className="admin-notice">No code is waiting for review. Add an unseen module above to prepare a provisional entry.</div>}</section>
    <section className="app-panel kb-approved-panel"><div className="kb-section-heading"><div><p className="section-label">KNOWLEDGE BASE</p><h2>Approved optimal references</h2></div></div>{entries.length ? <div className="kb-approved-list">{entries.map((entry) => <details key={entry.id}><summary><span><strong>{entry.topic}</strong><small>{entry.category} · {entry.variant} · {(entry.tags || []).join(", ")}</small></span><span className="kb-status approved">Approved</span></summary><p>{entry.description}</p><pre><code>{entry.optimal_code}</code></pre></details>)}</div> : <div className="admin-notice">The knowledge base has no approved code references yet. Add and approve provisional entries to build the project’s reference library.</div>}</section>
  </AdminWorkspace>;
}

import { useMemo, useState } from "react";
import { AdminButton, AdminNotice, AdminTable, AdminWorkspace } from "./AdminWorkspace";
import { useAdminRecords } from "./useAdminRecords";

export default function AdminAuditLogs() {
  const { records, error, loading, refresh } = useAdminRecords("/admin/audit-logs", "logs");
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => records.filter((log) => `${log.action} ${log.entity} ${log.description} ${log.entity_id}`.toLowerCase().includes(query.toLowerCase())), [records, query]);
  const columns = [
    { label: "Activity", render: (log) => <><strong>{String(log.action || "activity").replaceAll("_", " ")}</strong><small className="admin-subline">{log.description}</small></> },
    { label: "Area", render: (log) => <span className="admin-pill confirmed">{log.entity || "platform"}</span> },
    { label: "Record ID", render: (log) => log.entity_id ? <code className="admin-record-id">{log.entity_id}</code> : "—" },
    { label: "When", render: (log) => new Date(log.created_at).toLocaleString([], { dateStyle: "medium", timeStyle: "short" }) },
  ];
  return <AdminWorkspace title="Audit log" description="A chronological record of administrative changes made through this dashboard. Up to 100 most recent actions are shown." actions={<><input className="admin-input" aria-label="Search audit log" placeholder="Search activity" value={query} onChange={(e) => setQuery(e.target.value)} /><AdminButton tone="quiet" onClick={refresh}>Refresh</AdminButton></>}>
    <div className="admin-info-card"><span className="admin-info-icon">i</span><div><strong>What gets recorded</strong><p>Professional decisions, user account status changes, booking and complaint updates, service edits, maintenance schedule changes, and warranty issuance.</p></div></div>
    <section className="app-panel admin-panel"><AdminNotice error={error} loading={loading} count={filtered.length} empty="No administrative actions have been recorded yet. New actions will appear here as the team manages the platform." />{!loading && !error && filtered.length > 0 && <AdminTable columns={columns} rows={filtered} />}</section>
  </AdminWorkspace>;
}

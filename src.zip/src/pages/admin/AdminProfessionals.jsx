import { useEffect, useState } from "react";
import { FileText, X } from "lucide-react";
import { apiService } from "../../services/api";
import { AdminButton, AdminNotice, AdminTable, AdminWorkspace } from "./AdminWorkspace";
import { useAdminRecords } from "./useAdminRecords";

export default function AdminProfessionals() {
  const { records, setRecords, error, setError, loading, refresh } = useAdminRecords("/admin/professionals", "professionals");
  const [preview, setPreview] = useState(null);
  const [locationFilter, setLocationFilter] = useState("all");
  const [sortBy, setSortBy] = useState("rating");
  useEffect(() => () => { if (preview?.url) URL.revokeObjectURL(preview.url); }, [preview?.url]);
  async function setStatus(person, status) {
    try { const { data } = await apiService.patch(`/admin/professionals/${person.id}`, { status }); setRecords((list) => list.map((item) => item.id === person.id ? { ...item, ...data.professional, performance: item.performance, documents: item.documents } : item)); }
    catch (e) { setError(e.response?.data?.message || "Could not update application."); }
  }
  async function reviewDocument(person, document, status) {
    try {
      await apiService.patch(`/admin/professionals/${person.id}/documents/${document.id}`, { status });
      setRecords((list) => list.map((item) => item.id === person.id ? { ...item, documents: item.documents.map((doc) => doc.id === document.id ? { ...doc, review_status: status } : doc) } : item));
    } catch (e) { setError(e.response?.data?.message || "Could not review the document."); }
  }
  async function viewDocument(person, document) {
    try { const { data } = await apiService.get(`/admin/professionals/${person.id}/documents/${document.id}`); const bytes = Uint8Array.from(atob(data.contentBase64), (char) => char.charCodeAt(0)); const url = URL.createObjectURL(new Blob([bytes], { type: data.mimeType })); setPreview({ ...data, url, applicant: person.name, documentType: document.document_type }); }
    catch (e) { setError(e.response?.data?.message || "Could not open this document."); }
  }
  const locations = [...new Set(records.flatMap((person) => person.service_areas || []).map((area) => String(area).trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b));
  const visibleRecords = [...records].filter((person) => locationFilter === "all" || (person.service_areas || []).some((area) => area.toLowerCase() === locationFilter.toLowerCase())).sort((a, b) => {
    if (sortBy === "experience") return Number(b.experience_years || 0) - Number(a.experience_years || 0);
    if (sortBy === "name") return a.name.localeCompare(b.name);
    return Number(b.performance?.rating || 0) - Number(a.performance?.rating || 0) || Number(b.performance?.reviewCount || 0) - Number(a.performance?.reviewCount || 0);
  });
  const topLocation = locations.map((area) => ({ area, count: records.filter((person) => (person.service_areas || []).some((item) => item.toLowerCase() === area.toLowerCase())).length })).sort((a, b) => b.count - a.count)[0];
  const columns = [
    { label: "Applicant", render: (p) => <><strong>{p.name}</strong><small className="admin-subline">{p.email}</small></> },
    { label: "Professional details", render: (p) => <><strong>{p.specialty || "Not provided"}</strong><small className="admin-subline">{p.experience_years ?? "—"} years · {(p.service_areas || []).join(", ") || "Service area not provided"}</small></> },
    { label: "Applied", render: (p) => new Date(p.created_at).toLocaleDateString() },
    { label: "Status", render: (p) => <span className={`admin-pill ${p.status}`}>{p.status}</span> },
    { label: "Performance & feedback", render: (p) => <div className="admin-performance"><strong>{p.performance?.rating == null ? "No ratings" : `${p.performance.rating} / 5`} <small>· {p.performance?.reviewCount || 0} reviews</small></strong><small>{p.performance?.completedJobs || 0}/{p.performance?.assignedJobs || 0} jobs completed{p.performance?.completionRate == null ? "" : ` · ${p.performance.completionRate}%`}</small><div><span className="admin-feedback-positive">{p.performance?.positiveFeedback || 0} positive</span><span className="admin-feedback-critical">{p.performance?.criticalFeedback || 0} critical</span></div>{p.performance?.improvementNotes?.map((review, i) => <small className="admin-improvement-note" key={`${review.created_at}-${i}`}>“{review.comment}” · {review.rating}/5</small>)}</div> },
    { label: "Verification documents", render: (p) => p.documents?.length ? <div className="admin-document-list">{p.documents.map((doc) => <div key={doc.id}><span>{doc.document_type === "government_id" ? "Government ID" : "Professional credential"} · {doc.review_status}{doc.ai_image_screening && <small className="admin-subline">AI image screen: {doc.ai_image_screening.result === "ai_metadata_found" ? "AI metadata found — inspect manually" : doc.ai_image_screening.result === "no_ai_metadata_found" ? "No AI metadata found — not proof of originality" : "Not screened"}</small>}</span><button type="button" onClick={() => viewDocument(p, doc)}>View</button>{doc.review_status === "pending" && <><button type="button" onClick={() => reviewDocument(p, doc, "approved")}>Verify</button><button type="button" onClick={() => reviewDocument(p, doc, "rejected")}>Reject</button></>}</div>)}</div> : <span className="admin-subline">No documents submitted</span> },
    { label: "Review", render: (p) => { const verifiedId = p.documents?.some((doc) => doc.document_type === "government_id" && doc.review_status === "approved"); return <div className="admin-actions"><AdminButton disabled={p.status !== "approved" && !verifiedId} onClick={() => setStatus(p, "approved")}>Approve</AdminButton><AdminButton tone="quiet" onClick={() => setStatus(p, "rejected")}>Reject</AdminButton></div>; } },
  ];
  return <AdminWorkspace title="Professional applications" description="Review new providers and manage approval, service locations, experience, and customer feedback." actions={<><span>{records.filter((p) => p.status === "pending").length} applications awaiting review</span><AdminButton tone="quiet" onClick={refresh}>Refresh</AdminButton></>}><section className="app-panel admin-panel">{error && <div className="admin-notice error" role="alert">{error}</div>}{!loading && records.length > 0 && <div className="professional-admin-filters"><label>Service location<select value={locationFilter} onChange={(event) => setLocationFilter(event.target.value)}><option value="all">All locations ({records.length})</option>{locations.map((area) => <option key={area} value={area}>{area} ({records.filter((person) => (person.service_areas || []).some((item) => item.toLowerCase() === area.toLowerCase())).length})</option>)}</select></label><label>Sort professionals<select value={sortBy} onChange={(event) => setSortBy(event.target.value)}><option value="rating">Highest rated</option><option value="experience">Most experience</option><option value="name">Name</option></select></label><span>{topLocation ? `Top service area: ${topLocation.area} · ${topLocation.count} professional${topLocation.count === 1 ? "" : "s"}` : "No service areas recorded yet"}</span></div>}{loading ? <AdminNotice loading /> : visibleRecords.length ? <AdminTable columns={columns} rows={visibleRecords} /> : records.length ? <AdminNotice empty="No professionals serve this location." /> : <AdminNotice empty="No professional applications yet." />}</section>{preview && <div className="document-preview-backdrop" role="presentation" onClick={() => setPreview(null)}><section className="document-preview-modal" role="dialog" aria-modal="true" aria-label="Professional verification document" onClick={(event) => event.stopPropagation()}><header><div><span className="admin-info-icon"><FileText size={18} /></span><div><strong>{preview.fileName}</strong><small>{preview.applicant} · {preview.documentType === "government_id" ? "Government ID" : "Professional credential"}</small></div></div><button className="document-preview-close" aria-label="Close document preview" onClick={() => setPreview(null)}><X size={19} /></button></header>{preview.mimeType === "application/pdf" ? <iframe title={`Verification document for ${preview.applicant}`} src={preview.url} /> : <div className="document-image-frame"><img src={preview.url} alt={`Verification document submitted by ${preview.applicant}`} /></div>}</section></div>}</AdminWorkspace>;
}

import { useState } from "react";
import { apiService } from "../../services/api";
import { AdminButton, AdminNotice, AdminTable, AdminWorkspace } from "./AdminWorkspace";
import { useAdminRecords } from "./useAdminRecords";

const blank = { name: "", category: "", description: "", basePrice: "" };
export default function AdminCategories() {
  const { records, setRecords, error, setError, loading, refresh } = useAdminRecords("/admin/services", "services");
  const [form, setForm] = useState(blank);
  const [saving, setSaving] = useState(false);
  async function save(event) {
    event.preventDefault(); setSaving(true); setError("");
    try { const { data } = await apiService.post("/admin/services", { ...form, basePrice: Number(form.basePrice) }); setRecords((list) => [...list, data.service]); setForm(blank); }
    catch (e) { setError(e.response?.data?.message || "Could not save service. Check the API connection."); }
    finally { setSaving(false); }
  }
  async function toggle(service) {
    try { const { data } = await apiService.patch(`/admin/services/${service.id}`, { active: !service.active }); setRecords((list) => list.map((item) => item.id === service.id ? data.service : item)); }
    catch (e) { setError(e.response?.data?.message || "Could not update service."); }
  }
  async function edit(service) {
    const name = window.prompt("Service name", service.name); if (name === null) return;
    const category = window.prompt("Category", service.category); if (category === null) return;
    const price = window.prompt("Base price (₹)", service.base_price); if (price === null) return;
    const description = window.prompt("Customer-facing description", service.description || ""); if (description === null) return;
    try { const { data } = await apiService.patch(`/admin/services/${service.id}`, { name: name.trim(), category: category.trim(), basePrice: Number(price), description }); setRecords((list) => list.map((item) => item.id === service.id ? data.service : item)); }
    catch (e) { setError(e.response?.data?.message || "Could not update service."); }
  }
  const columns = [
    { label: "Service", render: (s) => <><strong>{s.name}</strong><small className="admin-subline">{s.description}</small></> },
    { label: "Category", key: "category" },
    { label: "Base price", render: (s) => `₹${Number(s.base_price).toLocaleString("en-IN")}` },
    { label: "Availability", render: (s) => <span className={`admin-pill ${s.active ? "approved" : "rejected"}`}>{s.active ? "Active" : "Disabled"}</span> },
    { label: "", render: (s) => <div className="admin-actions"><AdminButton tone="quiet" onClick={() => edit(s)}>Edit</AdminButton><AdminButton tone="quiet" onClick={() => toggle(s)}>{s.active ? "Disable" : "Enable"}</AdminButton></div> },
  ];
  return <AdminWorkspace title="Services and categories" description="Maintain the service catalogue, customer descriptions, and starting prices." actions={<AdminButton tone="quiet" onClick={refresh}>Refresh</AdminButton>}>
    <form className="app-panel admin-form" onSubmit={save}><div><p className="section-label">Add offering</p><h2>New service</h2></div><input className="admin-input" required maxLength={120} placeholder="Service name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /><input className="admin-input" required maxLength={80} placeholder="Category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /><input className="admin-input" required min="0" step="0.01" type="number" placeholder="Base price (₹)" value={form.basePrice} onChange={(e) => setForm({ ...form, basePrice: e.target.value })} /><input className="admin-input admin-description" maxLength={500} placeholder="Short customer-facing description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /><AdminButton type="submit" disabled={saving}>{saving ? "Saving…" : "Add service"}</AdminButton></form>
    <section className="app-panel admin-panel"><AdminNotice error={error} loading={loading} count={records.length} empty="No services found." />{!loading && !error && <AdminTable columns={columns} rows={records} />}</section>
  </AdminWorkspace>;
}

import PageFrame from "../../components/PageFrame";
import "./admin.css";

export function AdminWorkspace({ title, description, actions, children }) {
  return <PageFrame eyebrow="HomeCare AI · Operations" title={title} description={description}>
    {actions && <div className="admin-toolbar">{actions}</div>}{children}
  </PageFrame>;
}

export function AdminNotice({ error, loading, empty, count }) {
  if (error) return <div className="admin-notice error">{error}</div>;
  if (loading) return <div className="admin-notice">Loading records…</div>;
  if (!count) return <div className="admin-notice">{empty || "No records found."}</div>;
  return null;
}

export function AdminTable({ columns, rows, rowKey = "id" }) {
  return <div className="admin-table-wrap"><table className="admin-table"><thead><tr>{columns.map((column) => <th key={column.label}>{column.label}</th>)}</tr></thead><tbody>{rows.map((row) => <tr key={row[rowKey]}>{columns.map((column) => <td key={column.label}>{column.render ? column.render(row) : row[column.key] ?? "—"}</td>)}</tr>)}</tbody></table></div>;
}

export function AdminButton({ children, onClick, tone = "primary", disabled = false, type = "button" }) {
  return <button type={type} className={`admin-button ${tone}`} onClick={onClick} disabled={disabled}>{children}</button>;
}

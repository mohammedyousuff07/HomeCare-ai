import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, ArrowUpRight, CheckCircle2, Code2, Search, ShieldCheck, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import { AdminWorkspace } from "./AdminWorkspace";
import { apiService } from "../../services/api";
import { matchKnowledgeEntry, suggestKnowledgeMetadata } from "../../../shared/knowledgeMatching.js";

const mean = (entries, field) => entries.length
  ? entries.reduce((total, entry) => total + Number(entry.metrics?.[field] || 0), 0) / entries.length
  : 0;
const oneDecimal = (value) => Number(value || 0).toFixed(1);

function EvaluationReport() {
  const [evaluation, setEvaluation] = useState(null);
  const [reportError, setReportError] = useState("");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [knowledgeEntries, setKnowledgeEntries] = useState([]);
  const [selectedPath, setSelectedPath] = useState("");
  const [userCode, setUserCode] = useState("");
  const [codeLoading, setCodeLoading] = useState(true);
  const [codeError, setCodeError] = useState("");
  useEffect(() => {
    let active = true;
    fetch("/evaluation/latest-metrics.json", { cache: "no-store" })
      .then((response) => { if (!response.ok) throw new Error("Run the project evaluation pipeline to create the comparison report."); return response.json(); })
      .then((result) => { if (active) setEvaluation(result); })
      .catch((error) => { if (active) setReportError(error.message); });
    apiService.get("/admin/code-knowledge")
      .then(({ data }) => { if (active) setKnowledgeEntries(data.entries || []); })
      .catch(() => { if (active) setCodeError("Connect the admin API to load approved reference code."); });
    return () => { active = false; };
  }, []);
  const solutionEntries = useMemo(() => evaluation?.solution_entries || [], [evaluation]);
  const projectComposite = Number(evaluation?.score?.percentage || 0) / 10;
  const selectedModule = solutionEntries.find((entry) => entry.source_path === selectedPath) || solutionEntries[0];
  const matchedReference = selectedModule ? matchKnowledgeEntry({ category: selectedModule.category, topic: selectedModule.topic, variant: selectedModule.variant, tags: suggestKnowledgeMetadata({ sourcePath: selectedModule.source_path, ...selectedModule }).tags }, knowledgeEntries) : null;
  useEffect(() => {
    if (!selectedModule?.source_path) return undefined;
    let active = true;
    apiService.get("/admin/code-knowledge/source", { params: { path: selectedModule.source_path } })
      .then(({ data }) => { if (active) setUserCode(data.code || ""); })
      .catch((error) => { if (active) setCodeError(error.response?.data?.message || "Could not load this module’s source."); })
      .finally(() => { if (active) setCodeLoading(false); });
    return () => { active = false; };
  }, [selectedModule?.source_path]);
  const categories = [...new Set(solutionEntries.map((entry) => entry.category))];
  const comparisons = useMemo(() => [
    { metric: "Composite score", score: projectComposite, optimal: 10, note: "Weighted project truth-table result" },
    { metric: "Code quality · Oxlint", score: mean(solutionEntries, "oxlint_score"), optimal: 10, note: "Lower warnings improve the score" },
    { metric: "Complexity score", score: mean(solutionEntries, "complexity_score"), optimal: 10, note: "Average across JavaScript modules" },
    { metric: "Cyclomatic score", score: mean(solutionEntries, "cyclomatic_score"), optimal: 10, note: "Fewer decision branches score better" },
    { metric: "LOC score", score: mean(solutionEntries, "loc_score"), optimal: 10, note: "Module size rubric" },
    { metric: "Structure score", score: mean(solutionEntries, "structural_score"), optimal: 10, note: "Exports and module structure" },
    { metric: "Logic score", score: mean(solutionEntries, "logic_score"), optimal: 10, note: "Estimated branch complexity" },
    { metric: "Maintainability index", score: mean(solutionEntries, "maintainability_index") / 10, optimal: 10, note: "Estimated index normalized to 0–10" },
  ], [projectComposite, solutionEntries]);
  const filteredEntries = useMemo(() => solutionEntries.filter((entry) => {
    const matchesCategory = category === "all" || entry.category === category;
    const matchesQuery = `${entry.topic} ${entry.variant} ${entry.source_path}`.toLowerCase().includes(query.toLowerCase());
    return matchesCategory && matchesQuery;
  }), [category, query, solutionEntries]);

  if (!evaluation) return <AdminWorkspace title="Project comparison report" description="Compare HomeCare’s measured code metrics with the ideal values in its evaluation rubric."><section className="evaluation-panel app-panel">{reportError ? <p className="evaluation-load-error">{reportError}</p> : <p className="evaluation-loading">Loading the latest project evaluation…</p>}</section></AdminWorkspace>;

  return <AdminWorkspace title="Project comparison report" description="Compare HomeCare’s measured code metrics with the ideal values in its evaluation rubric." actions={<Link className="admin-button quiet" to="/admin/dashboard"><ArrowLeft size={14} /> Back to dashboard</Link>}>
    <section className="evaluation-hero">
      <div className="evaluation-hero-copy"><span className="evaluation-kicker"><Sparkles size={14} /> HOMECARE AI · CODE EVALUATION</span><h2>Comparison Report</h2><p>Measured project scores compared with the ideal score for each metric.</p><span className="evaluation-refresh">Latest run · {evaluation.generatedAt ? new Date(evaluation.generatedAt).toLocaleString() : "Not available"}</span></div>
      <div className="evaluation-score-ring" style={{ "--score-progress": `${projectComposite * 10}%` }}><span><strong>{oneDecimal(projectComposite)}</strong><small>/ 10</small></span></div>
      <div className="evaluation-score-caption"><strong>{evaluation.summary?.checksPassed || 0} of {evaluation.summary?.checksTotal || 0} checks passed</strong><span>Project composite score</span></div>
    </section>

    <section className="evaluation-panel app-panel">
      <div className="evaluation-panel-heading"><div><span className="section-label">TRUTH TABLE COMPARISON</span><h2>Your project vs. optimal scores</h2></div><span className="evaluation-scale">Scores out of 10</span></div>
      <div className="evaluation-table-scroll"><table className="evaluation-table"><thead><tr><th>Metric</th><th>Your score</th><th>Optimal score</th><th>Gap to optimal</th></tr></thead><tbody>{comparisons.map((row) => {
        const gap = row.optimal - row.score;
        return <tr key={row.metric}><td><strong>{row.metric}</strong><small>{row.note}</small></td><td><b>{oneDecimal(row.score)}</b><span className="evaluation-mini-track"><i style={{ width: `${Math.min(100, Math.max(0, row.score * 10))}%` }} /></span></td><td>{oneDecimal(row.optimal)}</td><td><span className={`evaluation-gap ${gap <= 0 ? "met" : "behind"}`}>{gap > 0 ? "+" : ""}{oneDecimal(gap)}{gap <= 0 && <CheckCircle2 size={14} />}</span></td></tr>;
      })}</tbody></table></div>
      <p className="evaluation-footnote"><ShieldCheck size={14} /> A positive gap means the measured score is below the rubric’s ideal. Per-file complexity and maintainability metrics are static estimates.</p>
    </section>

    <section className="evaluation-panel app-panel evaluation-solutions">
      <div className="evaluation-panel-heading"><div><span className="section-label">SOLUTION ENTRIES</span><h2>Module-level code metrics</h2><p>{filteredEntries.length} of {solutionEntries.length} JavaScript/JSX modules</p></div><Code2 size={20} /></div>
      <div className="evaluation-filters"><label className="evaluation-search"><Search size={15} /><input aria-label="Search modules" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search module or path" /></label><select aria-label="Filter by category" value={category} onChange={(event) => setCategory(event.target.value)}><option value="all">All categories</option>{categories.map((item) => <option key={item}>{item}</option>)}</select></div>
      <div className="evaluation-modules-scroll"><table className="evaluation-table evaluation-module-table"><thead><tr><th>Module</th><th>Variant</th><th>LOC</th><th>Functions</th><th>Cyclomatic</th><th>Maintainability</th><th>Composite</th></tr></thead><tbody>{filteredEntries.map((entry) => <tr key={entry.source_path}><td><strong>{entry.topic}</strong><small>{entry.source_path}</small></td><td>{entry.variant}</td><td>{entry.metrics.loc}</td><td>{entry.metrics.functions}</td><td>{entry.metrics.cyclomatic_complexity}</td><td>{entry.metrics.maintainability_index}/100</td><td><span className="evaluation-module-score">{oneDecimal(entry.metrics.composite_score)}<small>/10</small></span></td></tr>)}</tbody></table>{!filteredEntries.length && <div className="evaluation-empty">No modules match those filters.</div>}</div>
      <p className="evaluation-footnote"><ArrowUpRight size={14} /> This report uses the requirement-based knowledge-base rubric. It is not a comparison with a separate reference-code repository.</p>
      {solutionEntries.length > 0 && <section className="evaluation-code-reference"><div className="evaluation-panel-heading"><div><span className="section-label">OPTIMAL CODE REFERENCE</span><h2>Compare a module with the knowledge base</h2></div><select aria-label="Choose module to compare" value={selectedModule?.source_path || ""} onChange={(event) => { setSelectedPath(event.target.value); setCodeLoading(true); setCodeError(""); setUserCode(""); }}>{solutionEntries.map((entry) => <option value={entry.source_path} key={entry.source_path}>{entry.topic} · {entry.source_path}</option>)}</select></div>
        {matchedReference ? <div className="evaluation-reference-status matched"><CheckCircle2 size={15} /><span>Reference from KB: <b>{matchedReference.entry.topic}</b> · fuzzy match {Math.round(matchedReference.score * 100)}% · {matchedReference.entry.reference_source || "human reviewed"}</span></div> : <div className="evaluation-reference-status fallback"><span>No approved KB match. Your code is shown as the fallback reference.</span><Link to="/admin/knowledge-base">Review this topic in KB <ArrowUpRight size={13} /></Link></div>}
        {codeError && <p className="evaluation-code-error">{codeError}</p>}
        <div className="evaluation-code-columns"><article><header><strong>{matchedReference ? "Knowledge-base optimal code" : "Fallback reference code"}</strong><span>{matchedReference ? "Human approved" : "Not an optimal reference"}</span></header><pre><code>{codeLoading ? "Loading code…" : matchedReference?.entry.optimal_code || userCode || "Source unavailable"}</code></pre></article><article><header><strong>Your project code</strong><span>{selectedModule?.topic || "Selected module"}</span></header><pre><code>{codeLoading ? "Loading code…" : userCode || "Source unavailable"}</code></pre></article></div>
      </section>}
    </section>
  </AdminWorkspace>;
}

export default EvaluationReport;

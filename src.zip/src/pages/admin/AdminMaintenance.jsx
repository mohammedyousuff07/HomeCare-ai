import { useState } from "react";
import { apiService } from "../../services/api";
import { AdminButton, AdminNotice, AdminTable, AdminWorkspace } from "./AdminWorkspace";
import { useAdminRecords } from "./useAdminRecords";

const blank = { name: "", category: "", intervalDays: "", priority: "medium", description: "" };
export default function AdminMaintenance() {
  const { records, setRecords, error, setError, loading, refresh } = useAdminRecords("/admin/maintenance-rules", "rules");
  const [form, setForm] = useState(blank);
  const [saving, setSaving] = useState(false);
  async function createRule(event) {
    event.preventDefault(); setSaving(true); setError("");
    try { const { data } = await apiService.post("/admin/maintenance-rules", { ...form, intervalDays: Number(form.intervalDays) }); setRecords((list) => [...list, data.rule]); setForm(blank); }
    catch (e) { setError(e.response?.data?.message || "Could not create this schedule."); }
    finally { setSaving(false); }
  }
  async function toggle(rule) {
    try { const { data } = await apiService.patch(`/admin/maintenance-rules/${rule.id}`, { active: !rule.active }); setRecords((list) => list.map((item) => item.id === rule.id ? data.rule : item)); }
    catch (e) { setError(e.response?.data?.message || "Could not update this schedule."); }
  }
  const columns = [
    { label: "Maintenance task", render: (rule) => <><strong>{rule.name}</strong><small className="admin-subline">{rule.description || rule.category}</small></> },
    { label: "Category", key: "category" },
    { label: "Repeat interval", render: (rule) => `Every ${rule.interval_days} days` },
    { label: "Priority", render: (rule) => <span className={`admin-pill ${rule.priority === "high" ? "rejected" : rule.priority === "medium" ? "pending" : "confirmed"}`}>{rule.priority}</span> },
    { label: "Status", render: (rule) => <span className={`admin-pill ${rule.active ? "approved" : "rejected"}`}>{rule.active ? "Active" : "Paused"}</span> },
    { label: "Action", render: (rule) => <AdminButton tone="quiet" onClick={() => toggle(rule)}>{rule.active ? "Pause" : "Activate"}</AdminButton> },
  ];
  return <AdminWorkspace title="Maintenance schedules" description="Create and manage reusable preventive-care schedule rules for the service catalogue." actions={<AdminButton tone="quiet" onClick={refresh}>Refresh</AdminButton>}>
    <div className="admin-info-card"><span className="admin-info-icon">i</span><div><strong>How schedules work</strong><p>Each rule defines a recommended service and how often it should repeat. These rules are managed here; automatic customer reminders are not connected yet.</p></div></div>
    <form className="app-panel admin-form admin-form-grid" onSubmit={createRule}><div><p className="section-label">Schedule library</p><h2>Add a maintenance schedule</h2></div>
      <label>Task name<input className="admin-input" required placeholder="e.g. AC preventive service" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
      <label>Category<input className="admin-input" required placeholder="e.g. AC / HVAC" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /></label>
      <label>Repeat every (days)<input className="admin-input" required type="number" min="1" placeholder="180" value={form.intervalDays} onChange={(e) => setForm({ ...form, intervalDays: e.target.value })} /></label>
      <label>Priority<select className="admin-select" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label>
      <label className="admin-span-two">Description<input className="admin-input" placeholder="Short explanation customers can understand" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></label>
      <div className="admin-form-footer"><span className="admin-help">Set a reasonable interval based on the service type.</span><AdminButton type="submit" disabled={saving}>{saving ? "Saving…" : "Add schedule"}</AdminButton></div>
    </form>
    <section className="app-panel admin-panel"><h2>Schedule rules</h2><AdminNotice error={error} loading={loading} count={records.length} empty="No maintenance schedules yet. Add a rule above to start the schedule library." />{!loading && !error && records.length > 0 && <AdminTable columns={columns} rows={records} />}</section>
  </AdminWorkspace>;
}

import { useCallback, useEffect, useState } from "react";
import { apiService } from "../../services/api";

export function useAdminRecords(path, key) {
  const [records, setRecords] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    setLoading(true);
    try { const { data } = await apiService.get(path); setRecords(data[key] || []); setError(""); }
    catch (e) { setError(e.response?.data?.message || "Could not load records. Check that the HomeCare API and database are running."); }
    finally { setLoading(false); }
  }, [path, key]);
  useEffect(() => {
    let active = true;
    apiService.get(path).then(({ data }) => { if (active) { setRecords(data[key] || []); setError(""); } })
      .catch((e) => { if (active) setError(e.response?.data?.message || "Could not load records. Check that the HomeCare API and database are running."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [path, key]);
  return { records, setRecords, error, setError, loading, refresh };
}

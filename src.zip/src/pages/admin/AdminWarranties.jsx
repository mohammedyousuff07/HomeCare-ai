import { useEffect, useMemo, useState } from "react";
import { apiService } from "../../services/api";
import { AdminButton, AdminNotice, AdminTable, AdminWorkspace } from "./AdminWorkspace";
import { useAdminRecords } from "./useAdminRecords";

const defaultExpiry = () => { const date = new Date(); date.setDate(date.getDate() + 90); return date.toISOString().slice(0, 10); };
export default function AdminWarranties() {
  const { records, setRecords, error, setError, loading, refresh } = useAdminRecords("/admin/warranties", "warranties");
  const [completedBookings, setCompletedBookings] = useState([]);
  const [bookingId, setBookingId] = useState("");
  const [expiresAt, setExpiresAt] = useState(defaultExpiry);
  const [coverage, setCoverage] = useState("");
  const [saving, setSaving] = useState(false);
  useEffect(() => { apiService.get("/bookings").then(({ data }) => setCompletedBookings((data.bookings || []).filter((booking) => booking.status === "completed"))).catch(() => setCompletedBookings([])); }, []);
  const activeCount = useMemo(() => records.filter((warranty) => warranty.status === "active").length, [records]);
  async function issue(event) {
    event.preventDefault(); setSaving(true); setError("");
    try {
      const { data } = await apiService.post("/admin/warranties", { bookingId, expiresAt, coverage });
      const booking = completedBookings.find((item) => item.id === bookingId);
      setRecords((list) => [...list, { ...data.warranty, customer: booking?.customer, service: booking?.service, status: "active" }]);
      setBookingId(""); setCoverage(""); setExpiresAt(defaultExpiry());
    } catch (e) { setError(e.response?.data?.message || "Could not issue this warranty."); }
    finally { setSaving(false); }
  }
  const columns = [
    { label: "Service", render: (item) => <><strong>{item.service || "Service"}</strong><small className="admin-subline">Booking HC-{item.booking_id}</small></> },
    { label: "Customer", key: "customer" },
    { label: "Coverage", render: (item) => item.coverage || "Standard service warranty" },
    { label: "Expires", render: (item) => new Date(item.expires_at).toLocaleDateString() },
    { label: "Status", render: (item) => <span className={`admin-pill ${item.status === "active" ? "approved" : "rejected"}`}>{item.status}</span> },
  ];
  return <AdminWorkspace title="Warranty management" description="Issue and track service warranties. A warranty can only be issued against a completed booking." actions={<AdminButton tone="quiet" onClick={refresh}>Refresh</AdminButton>}>
    <div className="admin-stats admin-stats-three">{[["Total issued", records.length], ["Active", activeCount], ["Expired", records.length - activeCount]].map(([title, value]) => <article className="app-panel admin-stat" key={title}><div><small>{title}</small><strong>{loading ? "—" : value}</strong></div></article>)}</div>
    <form className="app-panel admin-form admin-form-grid" onSubmit={issue}><div><p className="section-label">Create warranty</p><h2>Issue service coverage</h2><p className="admin-help">Choose a completed job and set its coverage end date.</p></div>
      <label>Completed booking<select className="admin-select" required value={bookingId} onChange={(e) => setBookingId(e.target.value)}><option value="">Select a booking</option>{completedBookings.map((booking) => <option key={booking.id} value={booking.id}>HC-{booking.id} · {booking.service} · {booking.customer}</option>)}</select></label>
      <label>Valid until<input className="admin-input" type="date" required min={new Date().toISOString().slice(0, 10)} value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} /></label>
      <label className="admin-span-two">Coverage notes<input className="admin-input" placeholder="What's covered? (optional)" value={coverage} onChange={(e) => setCoverage(e.target.value)} /></label>
      <div className="admin-form-footer"><span className="admin-help">{completedBookings.length ? `${completedBookings.length} completed booking${completedBookings.length === 1 ? "" : "s"} available` : "Complete a booking before issuing its warranty."}</span><AdminButton disabled={saving || !completedBookings.length}>{saving ? "Saving…" : "Issue warranty"}</AdminButton></div>
    </form>
    <section className="app-panel admin-panel"><h2>Issued warranties</h2><AdminNotice error={error} loading={loading} count={records.length} empty="No warranties issued yet. Completed bookings become eligible above." />{!loading && !error && records.length > 0 && <AdminTable columns={columns} rows={records} />}</section>
  </AdminWorkspace>;
}

import { useMemo, useState } from "react";
import { apiService } from "../../services/api";
import { AdminButton, AdminNotice, AdminTable, AdminWorkspace } from "./AdminWorkspace";
import { useAdminRecords } from "./useAdminRecords";

const label = (value) => String(value || "").replaceAll("_", " ");
export default function AdminBookings() {
  const { records, setRecords, error, setError, loading, refresh } = useAdminRecords("/bookings", "bookings");
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const filtered = useMemo(() => records.filter((b) => (filter === "all" || b.status === filter) && `${b.id} ${b.customer} ${b.service} ${b.professional || ""}`.toLowerCase().includes(query.toLowerCase())), [records, filter, query]);
  async function update(id, data) {
    try { const result = await apiService.patch(`/bookings/${id}`, data); setRecords((list) => list.map((item) => item.id === id ? { ...item, ...(result.data.booking || data) } : item)); }
    catch (e) { setError(e.response?.data?.message || "Could not update booking."); }
  }
  const columns = [
    { label: "Booking", render: (b) => <><strong>HC-{b.id}</strong><small className="admin-subline">{b.service}</small></> },
    { label: "Customer / provider", render: (b) => <>{b.customer}<small className="admin-subline">{b.professional || "Unassigned"}</small></> },
    { label: "Schedule", render: (b) => new Date(b.scheduled_for).toLocaleString([], { dateStyle: "medium", timeStyle: "short" }) },
    { label: "Status", render: (b) => <select aria-label={`Status for booking ${b.id}`} className="admin-select" value={b.status} onChange={(e) => update(b.id, { status: e.target.value })}>{["pending", "confirmed", "in_progress", "completed", "cancelled"].map((s) => <option key={s} value={s}>{label(s)}</option>)}</select> },
  ];
  return <AdminWorkspace title="Bookings" description="Search service requests and keep scheduling status current." actions={<><input className="admin-input" placeholder="Search bookings" value={query} onChange={(e) => setQuery(e.target.value)} /><select className="admin-select" aria-label="Filter by status" value={filter} onChange={(e) => setFilter(e.target.value)}><option value="all">All statuses</option>{["pending", "confirmed", "in_progress", "completed", "cancelled"].map((s) => <option key={s} value={s}>{label(s)}</option>)}</select><AdminButton tone="quiet" onClick={refresh}>Refresh</AdminButton></>}><section className="app-panel admin-panel"><AdminNotice error={error} loading={loading} count={filtered.length} empty="No bookings match this search." />{!loading && !error && <AdminTable columns={columns} rows={filtered} />}</section></AdminWorkspace>;
}

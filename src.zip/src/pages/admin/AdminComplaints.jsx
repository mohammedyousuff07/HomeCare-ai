import { useEffect } from "react";
import { apiService } from "../../services/api";
import { AdminButton, AdminNotice, AdminTable, AdminWorkspace } from "./AdminWorkspace";
import { useAdminRecords } from "./useAdminRecords";

export default function AdminComplaints() {
  const { records, setRecords, error, setError, loading, refresh } = useAdminRecords("/admin/complaints", "complaints");
  useEffect(() => { const timer = window.setInterval(refresh, 20000); return () => window.clearInterval(timer); }, [refresh]);
  async function resolve(complaint) {
    const outcome = window.prompt("Record the resolution outcome", complaint.outcome || "");
    if (outcome === null) return;
    try { const { data } = await apiService.patch(`/admin/complaints/${complaint.id}`, { status: "resolved", outcome }); setRecords((list) => list.map((item) => item.id === complaint.id ? { ...item, ...data.complaint } : item)); }
    catch (e) { setError(e.response?.data?.message || "Could not update complaint."); }
  }
  async function investigate(complaint) {
    try { const { data } = await apiService.patch(`/admin/complaints/${complaint.id}`, { status: "investigating" }); setRecords((list) => list.map((item) => item.id === complaint.id ? { ...item, ...data.complaint } : item)); }
    catch (e) { setError(e.response?.data?.message || "Could not update complaint."); }
  }
  async function suspendProfessional(complaint) {
    if (!complaint.professional_id || !window.confirm(`Suspend ${complaint.professional || "the assigned professional"} while this complaint is reviewed?`)) return;
    try { await apiService.patch(`/admin/users/${complaint.professional_id}`, { status: "suspended" }); setRecords((list) => list.map((item) => item.id === complaint.id ? { ...item, professional_status: "suspended" } : item)); setError(""); }
    catch (e) { setError(e.response?.data?.message || "Could not suspend this professional account."); }
  }
  const columns = [
    { label: "Issue", render: (c) => <><strong>{c.subject}</strong><small className="admin-subline">{c.description || "No additional details"}</small></> },
    { label: "Customer", key: "customer" },
    { label: "Assigned professional", render: (c) => c.professional ? <><strong>{c.professional}</strong><small className="admin-subline">{c.professional_status === "suspended" ? "Account suspended" : `Account ${c.professional_status || "active"}`}</small></> : "Not assigned" },
    { label: "Booking", render: (c) => c.booking_id ? `HC-${c.booking_id}` : "—" },
    { label: "Reported", render: (c) => new Date(c.created_at).toLocaleDateString() },
    { label: "Status", render: (c) => <span className={`admin-pill ${c.status}`}>{c.status}</span> },
    { label: "Professional response", render: (c) => c.professional_response ? <><strong>Response received</strong><small className="admin-subline">{c.professional_response}</small></> : c.professional_id ? <span className="admin-subline">Waiting for the professional to respond</span> : <span className="admin-subline">No professional assigned</span> },
    { label: "Outcome / action", render: (c) => c.status === "resolved" ? (c.outcome || "Resolved") : <div className="admin-actions">{c.professional_id && c.professional_status !== "suspended" && <AdminButton tone="quiet" onClick={() => suspendProfessional(c)}>Suspend professional</AdminButton>}<AdminButton tone="quiet" onClick={() => investigate(c)}>Investigate</AdminButton><AdminButton onClick={() => resolve(c)}>Resolve</AdminButton></div> },
  ];
  return <AdminWorkspace title="Complaints and support" description="Track reported service problems and record how each case was resolved." actions={<><span>{records.filter((c) => c.status !== "resolved").length} cases need attention</span><AdminButton tone="quiet" onClick={refresh}>Refresh</AdminButton></>}><section className="app-panel admin-panel"><AdminNotice error={error} loading={loading} count={records.length} empty="No complaints have been reported." />{!loading && !error && <AdminTable columns={columns} rows={records} />}</section></AdminWorkspace>;
}

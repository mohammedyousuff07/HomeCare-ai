import { useMemo, useState } from "react";
import { apiService } from "../../services/api";
import { AdminButton, AdminNotice, AdminTable, AdminWorkspace } from "./AdminWorkspace";
import { useAdminRecords } from "./useAdminRecords";

export default function AdminUsers() {
  const { records, setRecords, error, setError, loading, refresh } = useAdminRecords("/admin/users", "users");
  const [query, setQuery] = useState("");
  const [role, setRole] = useState("all");
  const visible = useMemo(() => records.filter((user) => (role === "all" || user.role === role) && `${user.name} ${user.email}`.toLowerCase().includes(query.toLowerCase())), [records, role, query]);
  async function changeStatus(user) {
    const status = user.status === "suspended" ? "active" : "suspended";
    try {
      const { data } = await apiService.patch(`/admin/users/${user.id}`, { status });
      setRecords((list) => list.map((item) => item.id === user.id ? { ...item, ...data.user } : item));
      setError("");
    } catch (e) { setError(e.response?.data?.message || "Could not update this account."); }
  }
  const columns = [
    { label: "Account", render: (user) => <><strong>{user.name}</strong><small className="admin-subline">{user.email}</small></> },
    { label: "Role", render: (user) => <span className="admin-pill confirmed">{user.role}</span> },
    { label: "Joined", render: (user) => user.created_at ? new Date(user.created_at).toLocaleDateString() : "—" },
    { label: "Account status", render: (user) => <span className={`admin-pill ${user.status === "suspended" ? "rejected" : "approved"}`}>{user.status || "active"}</span> },
    { label: "Action", render: (user) => user.role === "admin" ? <small className="admin-subline">Admin accounts are protected</small> : <AdminButton tone="quiet" onClick={() => changeStatus(user)}>{user.status === "suspended" ? "Reactivate" : "Suspend"}</AdminButton> },
  ];
  return <AdminWorkspace title="User accounts" description="Search customer and professional accounts, review account status, and suspend or reactivate access." actions={<><input className="admin-input" aria-label="Search users" placeholder="Search name or email" value={query} onChange={(e) => setQuery(e.target.value)} /><select className="admin-select" aria-label="Filter users by role" value={role} onChange={(e) => setRole(e.target.value)}><option value="all">All roles</option><option value="customer">Customers</option><option value="professional">Professionals</option><option value="admin">Admins</option></select><AdminButton tone="quiet" onClick={refresh}>Refresh</AdminButton></>}>
    <div className="admin-stats admin-stats-three">{[["All accounts", records.length], ["Customers", records.filter((u) => u.role === "customer").length], ["Professionals", records.filter((u) => u.role === "professional").length]].map(([title, value]) => <article className="app-panel admin-stat" key={title}><div><small>{title}</small><strong>{loading ? "—" : value}</strong></div></article>)}</div>
    <section className="app-panel admin-panel"><AdminNotice error={error} loading={loading} count={visible.length} empty="No accounts match your search." />{!loading && !error && <AdminTable columns={columns} rows={visible} />}</section>
  </AdminWorkspace>;
}

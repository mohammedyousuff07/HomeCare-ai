import RolePage from "../../components/RolePage";
function AdminSection({ title }) { return <RolePage role="admin" title={title} description="Manage this area of the HomeCare AI platform."><div className="app-panel p-6"><div className="empty-state"><p>No records need attention right now.</p><button className="portal-secondary">Refresh view</button></div></div></RolePage>; }
export default AdminSection;

import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { BadgeCheck, Clock3, FileUp, ShieldCheck } from "lucide-react";
import PageFrame from "../../components/PageFrame";
import { useAuth } from "../../context/useAuth";
import { apiService } from "../../services/api";

const statusCopy = { pending: ["Application under review", "Your account is private while an admin reviews your application."], rejected: ["More information is needed", "Review the admin decision, then upload updated documents for another review."], approved: ["You are approved", "Your professional workspace is ready."] };

export default function ProfessionalApplication() {
  const { user, refreshAccount } = useAuth();
  const navigate = useNavigate();
  const [application, setApplication] = useState(null);
  const [documentType, setDocumentType] = useState("government_id");
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const refresh = useCallback(async () => {
    const { data } = await apiService.get("/professional/application");
    setApplication(data.application);
    await refreshAccount();
  }, [refreshAccount]);
  useEffect(() => { refresh().catch((e) => setError(e.response?.data?.message || "Unable to load your application.")); const timer = window.setInterval(() => refresh().catch(() => {}), 15000); return () => window.clearInterval(timer); }, [refresh]);
  async function submit(event) {
    event.preventDefault(); setError(""); setMessage("");
    if (!file) return setError("Choose a document to upload.");
    if (file.size > 5 * 1024 * 1024) return setError("The file must be smaller than 5 MB.");
    if (!['application/pdf', 'image/jpeg', 'image/png'].includes(file.type)) return setError("Upload a PDF, JPG, or PNG file.");
    setSaving(true);
    try {
      const contentBase64 = await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(",")[1]); reader.onerror = reject; reader.readAsDataURL(file); });
      const { data } = await apiService.post("/professional/application/documents", { documentType, fileName: file.name, mimeType: file.type, contentBase64 });
      const screening = data.aiImageScreening;
      setMessage(screening?.result === "ai_metadata_found"
        ? `${data.message} AI-generation metadata was detected; admin review is still required.`
        : screening?.result === "no_ai_metadata_found"
          ? `${data.message} No known AI-generation metadata was found; this does not prove the image is original.`
          : data.message);
      setFile(null); event.currentTarget.reset(); await refresh();
    } catch (e) { setError(e.response?.data?.message || "Unable to upload the document."); }
    finally { setSaving(false); }
  }
  const status = application?.user?.professional_status || user?.professional_status || "pending";
  useEffect(() => { if (status === "approved") navigate("/professional/dashboard", { replace: true }); }, [status, navigate]);
  const [heading, explanation] = statusCopy[status] || statusCopy.pending;
  const StatusIcon = status === "approved" ? BadgeCheck : status === "rejected" ? ShieldCheck : Clock3;
  return <PageFrame eyebrow="Professional verification" title="Complete your application" description="Only approved professionals can access jobs, customer details, and the service workspace.">
    <section className="app-panel application-status-card"><span className={`application-status-icon ${status}`}><StatusIcon size={23} /></span><div><span className={`status-badge ${status === "approved" ? "green" : status === "rejected" ? "amber" : "blue"}`}>{status}</span><h2>{heading}</h2><p>{explanation}</p></div></section>
    <div className="application-columns"><section className="app-panel application-card"><p className="section-label">Verify your identity</p><h2>Upload verification document</h2><p>Upload a government ID for identity review. You may also attach a professional license. We store the uploaded file for admin review and do not ask you to type the ID number.</p>
      <form onSubmit={submit} className="application-form"><label>Document type<select value={documentType} onChange={(event) => setDocumentType(event.target.value)}><option value="government_id">Government identity proof</option><option value="professional_license">Professional license or certificate</option></select></label><label className="application-upload"><FileUp size={22} /><strong>{file?.name || "Choose a PDF, JPG, or PNG"}</strong><small>Maximum file size: 5 MB</small><input type="file" accept="application/pdf,image/jpeg,image/png" onChange={(event) => setFile(event.target.files?.[0] || null)} /></label><p className="application-empty">Image screening checks for known AI-generator metadata only. It can miss generated images and may not be conclusive; every document still needs admin review.</p>{error && <p className="application-error" role="alert">{error}</p>}{message && <p className="application-success" role="status">{message}</p>}<button className="portal-primary" disabled={saving}>{saving ? "Uploading…" : "Submit for review"}</button></form>
    </section><aside className="app-panel application-card"><p className="section-label">Submitted documents</p><h2>Review status</h2>{application?.documents?.length ? application.documents.map((doc) => <div className="application-document" key={doc.id}><div><strong>{doc.document_type === "government_id" ? "Government ID" : "Professional credential"}</strong><small>{doc.file_name}</small>{doc.ai_image_screening && <small>AI image screen: {doc.ai_image_screening.result === "ai_metadata_found" ? "AI metadata found" : doc.ai_image_screening.result === "no_ai_metadata_found" ? "No AI metadata found (not proof of originality)" : "Manual review"}</small>}</div><span className={`status-badge ${doc.review_status === "approved" ? "green" : doc.review_status === "rejected" ? "amber" : "blue"}`}>{doc.review_status}</span></div>) : <p className="application-empty">No documents submitted yet. Upload an identity document to start verification.</p>}<div className="secure-note"><ShieldCheck size={15} /> Documents are available only to your account and authorized administrators.</div></aside></div>
  </PageFrame>;
}

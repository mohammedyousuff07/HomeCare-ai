import { useCallback, useEffect, useState } from "react";
import { Bell, CheckCircle2, RefreshCw, Send } from "lucide-react";
import { Link } from "react-router-dom";
import PageFrame from "../../components/PageFrame";
import { apiService } from "../../services/api";

export default function ProfessionalNotifications() {
  const [items, setItems] = useState([]); const [complaints, setComplaints] = useState([]); const [drafts, setDrafts] = useState({}); const [busy, setBusy] = useState(""); const [loading, setLoading] = useState(true); const [error, setError] = useState("");
  const refresh = useCallback(async () => {
    try {
      const [notificationResult, complaintResult] = await Promise.allSettled([apiService.get("/professional/notifications"), apiService.get("/professional/complaints")]);
      if (notificationResult.status === "rejected") throw notificationResult.reason;
      setItems(notificationResult.value.data.notifications || []);
      if (complaintResult.status === "fulfilled") { setComplaints(complaintResult.value.data.complaints || []); setError(""); }
      else { setError(complaintResult.reason.response?.data?.message || "Your notifications loaded, but customer concerns could not be refreshed."); }
    }
    catch (e) { setError(e.response?.data?.message || "Could not load your professional updates."); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { refresh(); const timer = window.setInterval(refresh, 20000); return () => window.clearInterval(timer); }, [refresh]);
  async function respond(complaint) {
    const response = (drafts[complaint.id] || "").trim(); if (!response) return;
    setBusy(complaint.id); setError("");
    try { const { data } = await apiService.post(`/professional/complaints/${complaint.id}/response`, { response }); setComplaints((rows) => rows.map((row) => row.id === complaint.id ? data.complaint : row)); setDrafts((itemsNow) => ({ ...itemsNow, [complaint.id]: "" })); }
    catch (e) { setError(e.response?.data?.message || "Could not send your response."); }
    finally { setBusy(""); }
  }
  return <PageFrame eyebrow="Professional workspace" title="Notifications and complaints" description="New customer requests and account updates appear here. Respond promptly when a customer reports a concern." actions={<button className="jobs-filter" type="button" onClick={() => { setLoading(true); refresh(); }}><RefreshCw size={14}/> Refresh</button>}>
    {error && <div className="professional-data-notice" role="alert">{error}</div>}
    <section className="professional-inbox-section"><div className="professional-inbox-title"><span><Bell size={18}/></span><div><h2>Recent updates</h2><p>Booking, payment, and account notifications.</p></div></div>{loading ? <p className="professional-empty">Loading notifications…</p> : items.length ? <div className="service-list">{items.map((item) => <article className="service-row" key={item.id}><span className="service-icon blue"><Bell size={20}/></span><span className="service-copy"><strong>{item.title || "HomeCare update"}</strong><small>{item.message} · {new Date(item.created_at).toLocaleString()}</small></span>{item.booking_id && <Link className="panel-link" to={`/professional/jobs/${item.booking_id}`}>View job</Link>}{item.read_at && <CheckCircle2 className="text-teal" size={18}/>}</article>)}</div> : <div className="professional-inbox-empty">You’re all caught up. New job and payment updates will appear here.</div>}</section>
    <section className="professional-inbox-section"><div className="professional-inbox-title"><span className="complaint"><CheckCircle2 size={18}/></span><div><h2>Customer concerns</h2><p>Send your response to the customer and admin team from here.</p></div></div>{loading ? <p className="professional-empty">Loading complaints…</p> : complaints.length ? <div className="professional-complaint-list">{complaints.map((complaint) => <article className="professional-complaint-card" key={complaint.id}><div className="professional-complaint-card-head"><div><span className={`admin-pill ${complaint.status}`}>{complaint.status}</span><h3>{complaint.subject}</h3><p>{complaint.description || "No additional details"}</p><small>{complaint.customer || "Customer"} · {new Date(complaint.created_at).toLocaleString()}</small></div>{complaint.booking_id && <Link className="panel-link" to={`/professional/jobs/${complaint.booking_id}`}>View job</Link>}</div>{complaint.professional_response ? <div className="professional-complaint-response"><strong>Your response sent</strong><p>{complaint.professional_response}</p><small>{complaint.professional_responded_at ? new Date(complaint.professional_responded_at).toLocaleString() : ""}</small></div> : complaint.status !== "resolved" && <form className="professional-complaint-reply" onSubmit={(event) => { event.preventDefault(); respond(complaint); }}><label htmlFor={`complaint-response-${complaint.id}`}>Your response</label><textarea id={`complaint-response-${complaint.id}`} maxLength={2000} rows={3} placeholder="Acknowledge the issue and explain your next step…" value={drafts[complaint.id] || ""} onChange={(event) => setDrafts((current) => ({ ...current, [complaint.id]: event.target.value }))}/><button className="portal-primary" disabled={busy === complaint.id || !(drafts[complaint.id] || "").trim()}><Send size={15}/>{busy === complaint.id ? "Sending…" : "Send response"}</button></form>}</article>)}</div> : <div className="professional-inbox-empty">No customer concerns are assigned to you.</div>}</section>
  </PageFrame>;
}

import { useEffect, useState } from "react";
import { Check, Clock3 } from "lucide-react";
import PageFrame from "../../components/PageFrame";
import { apiService } from "../../services/api";

const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const defaultSchedule = () => days.map((day, index) => ({ day, enabled: index < 5, start: "09:00", end: "18:00" }));
export default function ProfessionalAvailability() {
  const [schedule, setSchedule] = useState(defaultSchedule);
  const [loading, setLoading] = useState(true); const [saving, setSaving] = useState(false); const [message, setMessage] = useState("");
  useEffect(() => { apiService.get("/professional/availability").then(({ data }) => setSchedule(data.weeklyAvailability || defaultSchedule())).catch((e) => setMessage(e.response?.data?.message || "Could not load availability.")).finally(() => setLoading(false)); }, []);
  function update(index, changes) { setSchedule((current) => current.map((item, i) => i === index ? { ...item, ...changes } : item)); }
  async function save() { setSaving(true); setMessage(""); try { const { data } = await apiService.put("/professional/availability", { weeklyAvailability: schedule }); setSchedule(data.weeklyAvailability); setMessage("Your weekly availability was saved."); } catch (e) { setMessage(e.response?.data?.message || "Could not save availability."); } finally { setSaving(false); } }
  return <PageFrame eyebrow="Professional workspace" title="Working hours" description="Set your regular weekly hours. Customers can only request times that fit your availability.">
    <div className="availability-layout"><section className="app-panel schedule-panel availability-settings"><div className="availability-toolbar"><div><p className="section-label">Weekly schedule</p><h2>Your working hours</h2></div><button className="portal-primary availability-save" onClick={save} disabled={saving || loading}><Check size={15} /> {saving ? "Saving…" : "Save schedule"}</button></div>{loading ? <p className="professional-empty">Loading saved schedule…</p> : schedule.map((item, index) => <div className="availability-day-row" key={item.day}><label><input type="checkbox" checked={item.enabled} onChange={(event) => update(index, { enabled: event.target.checked })} /><strong>{item.day}</strong></label><input aria-label={`${item.day} start time`} type="time" disabled={!item.enabled} value={item.start} onChange={(event) => update(index, { start: event.target.value })} /><span>to</span><input aria-label={`${item.day} end time`} type="time" disabled={!item.enabled} value={item.end} onChange={(event) => update(index, { end: event.target.value })} /></div>)}{message && <p className="availability-message" role="status">{message}</p>}</section><aside className="app-panel schedule-panel"><p className="section-label">Availability rules</p><h2>What customers can book</h2><p className="availability-description">Your saved weekly hours help schedule new service requests. Existing assigned bookings remain visible even if you later change your hours.</p><div className="availability-tip"><Clock3 size={15} /><span>Keep your hours current. The booking schedule is based on your local time.</span></div></aside></div>
  </PageFrame>;
}

import { IndianRupee, WalletCards } from "lucide-react";
import PageFrame from "../../components/PageFrame";
import { useProfessionalData } from "./useProfessionalData";

const money = (amount) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount || 0);
export default function ProfessionalEarnings() {
  const { data, loading, error } = useProfessionalData();
  const paidJobs = (data?.jobs || []).filter((job) => job.status === "completed" && job.payment?.status === "paid");
  const gross = paidJobs.reduce((total, job) => total + Number(job.payment?.amount ?? job.final_price ?? job.quoted_price ?? 0), 0);
  return <PageFrame eyebrow="Professional workspace" title="Earnings" description="Review payments confirmed as received for your completed bookings.">{error && <div className="professional-data-notice" role="alert">{error}</div>}<div className="earnings-grid"><div className="earnings-total-card"><span className="earnings-icon"><WalletCards size={19} /></span><p className="section-label">Confirmed payments</p><strong>{loading ? "—" : money(gross)}</strong><small>Customer payments confirmed received · {paidJobs.length} jobs</small></div><div className="app-panel earnings-breakdown"><div className="earnings-heading"><div><p className="section-label">Account record</p><h2>Paid completed bookings</h2></div></div>{loading ? <p className="professional-empty">Loading payment totals…</p> : paidJobs.length ? paidJobs.map((job) => <div className="payment-row" key={job.id}><span><IndianRupee size={15} /><b>{job.service || "Home service"}</b></span><strong>{money(job.payment?.amount ?? job.final_price ?? job.quoted_price)}</strong></div>) : <p className="professional-empty">No confirmed payments yet. Once you confirm receipt of a customer payment, it will appear here.</p>}</div></div></PageFrame>;
}

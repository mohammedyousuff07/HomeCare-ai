import { useCallback, useEffect, useState } from "react";
import { apiService } from "../../services/api";

export function useProfessionalData() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const refresh = useCallback(async () => {
    try { const response = await apiService.get("/professional/me"); setData(response.data); setError(""); }
    catch (e) { setError(e.response?.data?.message || "Unable to load your professional data."); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => {
    refresh();
    const timer = window.setInterval(refresh, 30000);
    return () => window.clearInterval(timer);
  }, [refresh]);
  return { data, loading, error, refresh };
}

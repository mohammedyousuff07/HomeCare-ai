import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, BriefcaseBusiness, Home, Moon, ShieldCheck, Sun } from "lucide-react";
import { ROLE_DASHBOARD_MAP, useAuth } from "../context/useAuth";

function Register() {
  const navigate = useNavigate();
  const { register, theme, toggleTheme } = useAuth();
  const [selectedRole, setSelectedRole] = useState("customer");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [professional, setProfessional] = useState({ specialty: "AC & HVAC", experienceYears: "", serviceCity: "" });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault(); setSaving(true); setError("");
    try {
      const account = await register({ name: name.trim(), email: email.trim(), phone: phone.trim(), password, role: selectedRole, ...(selectedRole === "professional" ? { professionalProfile: { ...professional, experienceYears: Number(professional.experienceYears) } } : {}) });
      navigate(ROLE_DASHBOARD_MAP[account.role] || "/dashboard");
    } catch (e) {
      setError(e.response?.data?.message || "Could not create your account. Check that the API and database are running.");
    } finally { setSaving(false); }
  }

  return <div className="portal-shell flex min-h-screen items-center justify-center px-5"><div className="auth-panel">
    <div className="auth-brand-row"><Link to="/" className="app-brand"><span className="app-logo"><Home size={20} /></span><span><strong>HomeCare</strong> <em>AI</em><small>Home management</small></span></Link><button type="button" className="theme-toggle" onClick={toggleTheme} aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`} title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}>{theme === "dark" ? <Sun size={18}/> : <Moon size={18}/>}<span>{theme === "dark" ? "Light" : "Dark"}</span></button></div>
    <p className="section-label mt-10">Get started</p><h1 className="mt-2 text-3xl font-bold text-portal-navy">{selectedRole === "professional" ? "Join the HomeCare network" : "Create your home account"}</h1><p className="mt-2 text-sm text-portal-muted">{selectedRole === "professional" ? "Set up your service profile. Admin approval is required before customers can find you." : "Create an account to request and manage home services."}</p>
    <form onSubmit={handleSubmit} className="mt-7 space-y-4">
      <label className="auth-label">Account type<select className="auth-input" value={selectedRole} onChange={(event) => { setSelectedRole(event.target.value); setError(""); }}><option value="customer">Customer</option><option value="professional">Professional</option></select></label>
      {selectedRole === "professional" && <div className="professional-onboarding"><div className="verification-step-head"><BriefcaseBusiness size={18} /><div><strong>Professional profile</strong><small>Your application will be reviewed by an admin.</small></div></div><label className="auth-label">Primary service<select className="auth-input" value={professional.specialty} onChange={(event) => setProfessional({ ...professional, specialty: event.target.value })}><option>AC & HVAC</option><option>Plumbing</option><option>Electrical</option><option>Cleaning</option><option>Appliance repair</option></select></label><div className="form-grid"><label className="auth-label">Experience (years)<input className="auth-input" type="number" min="0" max="50" value={professional.experienceYears} onChange={(event) => setProfessional({ ...professional, experienceYears: event.target.value })} required /></label><label className="auth-label">Service city<input className="auth-input" value={professional.serviceCity} onChange={(event) => setProfessional({ ...professional, serviceCity: event.target.value })} placeholder="e.g. Bengaluru" required /></label></div><div className="secure-note"><ShieldCheck size={15} /> You will upload identity proof securely after creating your account. Your ID number is not requested in this form.</div></div>}
      <label className="auth-label">Your name<input className="auth-input" autoComplete="name" placeholder="Your full name" value={name} onChange={(event) => setName(event.target.value)} required /></label>
      <label className="auth-label">Email address<input className="auth-input" type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={(event) => setEmail(event.target.value)} required /></label>
      <label className="auth-label">Phone number <span className="text-xs text-slate-500">(optional)</span><input className="auth-input" type="tel" autoComplete="tel" placeholder="Your contact number" value={phone} onChange={(event) => setPhone(event.target.value)} /></label>
      <label className="auth-label">Password<input className="auth-input" type="password" autoComplete="new-password" minLength="8" placeholder="At least 8 characters" value={password} onChange={(event) => setPassword(event.target.value)} required /></label>
      {error && <p className="rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700" role="alert">{error}</p>}
      <button className="portal-primary w-full" type="submit" disabled={saving}>{saving ? "Saving account…" : "Create account"}<ArrowRight size={16} /></button>
    </form>
    <p className="mt-6 text-center text-sm text-portal-muted">Already have an account? <Link className="font-bold text-[#1769a5]" to="/login">Sign in</Link></p>
  </div></div>;
}

export default Register;

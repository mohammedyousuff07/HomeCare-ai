import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, Home, Moon, Sun } from "lucide-react";
import { ROLE_DASHBOARD_MAP, useAuth } from "../context/useAuth";

const demoProfiles = {
  customer: { email: "priya@homecare.ai" },
  professional: { email: "aarav@homecare.ai" },
  admin: { email: "admin@homecare.ai" },
};

function Login() {
  const navigate = useNavigate();
  const { login, theme, toggleTheme } = useAuth();
  const [selectedRole, setSelectedRole] = useState("customer");
  const [email, setEmail] = useState(demoProfiles.customer.email);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => { setEmail(demoProfiles[selectedRole].email); setPassword(""); setError(""); }, [selectedRole]);

  async function handleSubmit(event) {
    event.preventDefault(); setSaving(true); setError("");
    try {
      const account = await login({ email: email.trim(), password, role: selectedRole });
      navigate(ROLE_DASHBOARD_MAP[account.role] || "/dashboard");
    } catch (e) {
      setError(e.response?.data?.message || "Could not sign in. Check that the API and database are running.");
    } finally { setSaving(false); }
  }

  return <div className="portal-shell flex min-h-screen items-center justify-center px-5"><div className="auth-panel">
    <div className="auth-brand-row"><Link to="/" className="app-brand"><span className="app-logo"><Home size={20} /></span><span><strong>HomeCare</strong> <em>AI</em><small>Home management</small></span></Link><button type="button" className="theme-toggle" onClick={toggleTheme} aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`} title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}>{theme === "dark" ? <Sun size={18}/> : <Moon size={18}/>}<span>{theme === "dark" ? "Light" : "Dark"}</span></button></div>
    <p className="section-label mt-10">Welcome back</p><h1 className="mt-2 text-3xl font-bold text-portal-navy">Sign in to your {selectedRole === "professional" ? "professional workspace" : selectedRole === "admin" ? "admin workspace" : "home"}</h1><p className="mt-2 text-sm text-portal-muted">Use the email and password for your HomeCare account.</p>
    <form onSubmit={handleSubmit} className="mt-7 space-y-4">
      <label className="auth-label">Access as<select className="auth-input" value={selectedRole} onChange={(event) => setSelectedRole(event.target.value)}><option value="customer">Customer</option><option value="professional">Professional</option><option value="admin">Admin</option></select></label>
      <label className="auth-label">Email address<input className="auth-input" type="email" autoComplete="username" value={email} onChange={(event) => setEmail(event.target.value)} required /></label>
      <label className="auth-label">Password<input className="auth-input" type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter password" required /></label>
      {email.trim().toLowerCase() === demoProfiles[selectedRole].email && <p className="text-xs text-slate-500">Demo account password: <strong>password123</strong>. Other accounts use the password chosen during sign-up.</p>}
      {error && <p className="rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700" role="alert">{error}</p>}
      <button className="portal-primary w-full" type="submit" disabled={saving}>{saving ? "Signing in…" : "Sign in"}<ArrowRight size={16} /></button>
    </form>
    <p className="mt-6 text-center text-sm text-portal-muted">New to HomeCare AI? <Link className="font-bold text-[#1769a5]" to="/register">Create an account</Link></p>
    {selectedRole === "admin" && <p className="mt-3 text-center text-xs text-slate-500">Admin accounts are managed by the system and cannot be created from sign-up.</p>}
  </div></div>;
}

export default Login;

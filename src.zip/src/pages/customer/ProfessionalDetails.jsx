import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, MapPin, ShieldCheck } from "lucide-react";
import PageFrame from "../../components/PageFrame";
import { apiService } from "../../services/api";

function ProfessionalDetails() {
  const { id } = useParams();
  const [professional, setProfessional] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => { apiService.get(`/professionals/${id}`).then(({ data }) => setProfessional(data.professional)).catch((e) => setError(e.response?.data?.message || "Could not load this professional.")); }, [id]);
  return <PageFrame eyebrow="Professional profile" title={professional?.name || "Professional details"} description={professional?.skill || "Approved HomeCare service provider"}>
    {error ? <div className="app-panel p-6 text-sm text-red-700">{error}</div> : !professional ? <div className="app-panel p-6 text-sm text-slate-500">Loading professional details…</div> : <div className="app-panel p-6"><div className="flex items-center gap-4"><div className="professional-avatar">{professional.name.charAt(0)}</div><div><h2 className="text-xl font-bold text-portal-navy">{professional.name}</h2><p className="card-muted">{professional.experience}</p></div><ShieldCheck className="ml-auto text-teal" /></div><div className="professional-detail-metrics"><span><MapPin size={15} /> {professional.service_area}</span><span>{professional.verified ? "Approved professional" : "Review pending"}</span></div><p className="mt-5 text-sm text-slate-600">Contact details are shared after a service request is assigned.</p><Link className="portal-primary mt-6" to={`/bookings?professional=${id}`}>Request a service <ArrowLeft className="rotate-180" size={16} /></Link></div>}
  </PageFrame>;
}

export default ProfessionalDetails;

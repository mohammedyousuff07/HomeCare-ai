import { Link } from "react-router-dom";
import { ArrowRight, Bell, CalendarDays, CheckCircle2, ChevronRight, Clock3, Home, Plus, ShieldCheck, Sparkles, Wrench } from "lucide-react";
import PageFrame from "../../components/PageFrame";
import { useAuth } from "../../context/useAuth";
import { useCustomerData } from "./useCustomerData";

const date = (value) => value ? new Date(value).toLocaleString([], { weekday: "short", day: "numeric", month: "short", hour: "numeric", minute: "2-digit" }) : "Date to be arranged";
const statusLabel = (value) => ({ pending: "Requested", confirmed: "Confirmed", in_progress: "In progress", completed: "Completed", cancelled: "Cancelled" }[value] || "Requested");

export default function Dashboard() {
  const { user } = useAuth();
  const { data, loading, error, refresh } = useCustomerData();
  const properties = data?.properties || [];
  const bookings = data?.bookings || [];
  const nextBooking = bookings.filter((item) => ["pending", "confirmed", "in_progress"].includes(item.status) && new Date(item.scheduled_for) >= new Date()).sort((a, b) => new Date(a.scheduled_for) - new Date(b.scheduled_for))[0];
  const nextTask = (data?.maintenanceTasks || []).filter((item) => !["completed", "cancelled"].includes(item.status) && new Date(item.due_at) >= new Date()).sort((a, b) => new Date(a.due_at) - new Date(b.due_at))[0];
  const completed = bookings.filter((item) => item.status === "completed").sort((a, b) => new Date(b.scheduled_for) - new Date(a.scheduled_for)).slice(0, 3);
  const firstName = user?.name?.split(" ")[0] || "there";

  return <PageFrame eyebrow="Customer home" title={`Hello, ${firstName}`} description="Your homes, appointments and service records in one place.">
    {error && <div className="customer-notice" role="alert">{error}<button className="customer-retry-button" type="button" onClick={() => refresh().catch(() => {})}>Try again</button></div>}
    <section className="customer-home-hero">
      <div className="customer-home-hero-copy">
        <span className="customer-home-kicker"><Sparkles size={14}/> HOMECARE OVERVIEW</span>
        <h2>{properties.length ? properties[0].name : "Start with your home"}</h2>
        <p>{properties.length ? properties[0].address : "Save your home details once to make bookings and home records easier to manage."}</p>
        <div className="customer-home-hero-actions"><Link className="customer-home-main-action" to={properties.length ? "/bookings" : "/my-home"}>{properties.length ? <><Plus size={16}/>Book a service</> : <><Home size={16}/>Set up my home</>}</Link>{properties.length > 0 && <Link className="customer-home-text-action" to="/my-home">Manage homes <ArrowRight size={15}/></Link>}</div>
      </div>
      <div className="customer-home-art" aria-hidden="true"><span className="home-art-sun"/><span className="home-art-roof"/><span className="home-art-house"><i/><b/><em/></span><span className="home-art-plant">✳</span></div>
    </section>

    <section className="customer-summary-grid" aria-label="Account summary">
      {[["Saved homes", data?.stats?.propertyCount ?? 0, Home, "blue"], ["Upcoming bookings", data?.stats?.activeBookings ?? 0, CalendarDays, "green"], ["Completed services", data?.stats?.completedBookings ?? 0, CheckCircle2, "violet"], ["Active warranties", data?.stats?.activeWarranties ?? 0, ShieldCheck, "gold"]].map(([label, value, Icon, color]) => <article className="customer-summary-card" key={label}><span className={`customer-summary-icon ${color}`}><Icon size={18}/></span><span className="customer-summary-label">{label}</span><strong>{loading ? "—" : value}</strong></article>)}
    </section>

    <div className="customer-dashboard-grid">
      <section className="app-panel customer-dashboard-panel">
        <div className="customer-dashboard-heading"><div><span className="customer-home-kicker">YOUR SCHEDULE</span><h2>Upcoming</h2></div><Link to="/bookings">All bookings <ArrowRight size={14}/></Link></div>
        {loading ? <p className="customer-dashboard-empty">Loading your bookings…</p> : nextBooking ? <Link className="customer-upcoming-card" to={`/bookings/${nextBooking.id}`}><span className="customer-upcoming-icon"><CalendarDays size={19}/></span><span className="customer-upcoming-copy"><strong>{nextBooking.service || nextBooking.service_name || "Home service"}</strong><small><Clock3 size={13}/>{date(nextBooking.scheduled_for)}</small><small><Home size={13}/>{[nextBooking.room, nextBooking.address].filter(Boolean).join(" · ")}</small></span><span className={`customer-status-pill ${nextBooking.status}`}>{statusLabel(nextBooking.status)}</span></Link> : <div className="customer-dashboard-empty-block"><span><CalendarDays size={20}/></span><div><strong>No upcoming bookings</strong><p>When you book a service, its details will appear here.</p></div><Link to="/bookings">Browse services <ArrowRight size={14}/></Link></div>}
        <div className="customer-maintenance-strip"><span><Wrench size={16}/></span><div><small>NEXT MAINTENANCE REMINDER</small><strong>{nextTask?.name || nextTask?.title || "No reminders set"}</strong><p>{nextTask ? `Due ${date(nextTask.due_at)}` : "Create a reminder to keep track of home maintenance."}</p></div><Link to="/maintenance" aria-label="View maintenance reminders"><ChevronRight size={18}/></Link></div>
      </section>

      <aside className="app-panel customer-dashboard-panel customer-shortcuts-panel"><span className="customer-home-kicker">QUICK LINKS</span><h2>What would you like to do?</h2><div className="customer-shortcuts"><Link to="/bookings"><span className="shortcut-icon blue"><Plus size={17}/></span><span><strong>Book a service</strong><small>Choose a service and time</small></span><ChevronRight size={16}/></Link><Link to="/my-home"><span className="shortcut-icon green"><Home size={17}/></span><span><strong>Manage my home</strong><small>Update address and rooms</small></span><ChevronRight size={16}/></Link><Link to="/report-problem"><span className="shortcut-icon coral"><Wrench size={17}/></span><span><strong>Report a problem</strong><small>Send an issue to the team</small></span><ChevronRight size={16}/></Link><Link to="/notifications"><span className="shortcut-icon gold"><Bell size={17}/></span><span><strong>Notifications</strong><small>See booking updates</small></span><ChevronRight size={16}/></Link></div></aside>
    </div>

    <section className="app-panel customer-dashboard-panel customer-history-panel"><div className="customer-dashboard-heading"><div><span className="customer-home-kicker">SERVICE RECORD</span><h2>Recently completed</h2></div><Link to="/service-history">View history <ArrowRight size={14}/></Link></div>{loading ? <p className="customer-dashboard-empty">Loading service history…</p> : completed.length ? <div className="customer-history-list">{completed.map((item)=><Link key={item.id} to={`/bookings/${item.id}`}><span className="history-check"><CheckCircle2 size={17}/></span><span><strong>{item.service || item.service_name || "Home service"}</strong><small>{date(item.scheduled_for)}{item.professional ? ` · ${item.professional}` : ""}</small></span><ChevronRight size={17}/></Link>)}</div> : <p className="customer-dashboard-empty">Completed bookings will appear here.</p>}</section>
  </PageFrame>;
}

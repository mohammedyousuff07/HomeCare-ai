import { AlertTriangle, Phone } from "lucide-react";
import PageFrame from "../../components/PageFrame";
function Emergency() { return <PageFrame eyebrow="Urgent assistance" title="Emergency Help" description="For immediate danger, contact local emergency services first."><div className="emergency-panel"><AlertTriangle size={26} /><div><h2>Is someone or something at immediate risk?</h2><p>For fire, gas leaks, electrical sparking or severe flooding, call your local emergency number. HomeCare AI is not a replacement for emergency services.</p><a href="tel:112" className="emergency-button"><Phone size={16} /> Call emergency services</a></div></div></PageFrame> }
export default Emergency;

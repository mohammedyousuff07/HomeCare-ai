import { useEffect, useState } from "react";
import Navbar from "../../components/Navbar";
import Sidebar from "../../components/Sidebar";
import ProfessionalCard from "../../components/ProfessionalCard";
import { apiService } from "../../services/api";

function Professionals() {
  const [professionals, setProfessionals] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    apiService.get("/professionals")
      .then(({ data }) => setProfessionals(data.professionals || []))
      .catch(() => setError("Could not load approved professionals. Check that the API and database are running."))
      .finally(() => setLoading(false));
  }, []);
  return <div className="portal-shell min-h-screen"><Navbar /><div className="flex"><Sidebar /><main className="flex-1 p-6 lg:p-8"><div className="mx-auto max-w-6xl">
    <p className="section-label">Local service providers</p><h1 className="text-3xl font-bold">Verified professionals</h1><p className="mt-2 text-slate-500">Browse professionals approved by HomeCare and their saved service details.</p>
    {error && <div className="mt-6 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700" role="alert">{error}</div>}
    {loading && <div className="mt-8 rounded-xl border border-slate-200 bg-white p-6 text-sm text-slate-500">Loading approved professionals…</div>}
    {!loading && !error && professionals.length === 0 && <div className="mt-8 rounded-xl border border-slate-200 bg-white p-6 text-sm text-slate-500">No professionals have been approved yet.</div>}
    {!loading && !error && professionals.length > 0 && <div className="mt-8 grid gap-6 md:grid-cols-2 xl:grid-cols-3">{professionals.map((professional) => <ProfessionalCard key={professional.id} professional={professional} />)}</div>}
  </div></main></div></div>;
}

export default Professionals;

import { useState } from "react";
import { Bath, BedDouble, Building2, CookingPot, Home, MapPin, Pencil, Plus, Save, Sofa, X } from "lucide-react";
import PageFrame from "../../components/PageFrame";
import { apiService } from "../../services/api";
import { useCustomerData } from "./useCustomerData";

const roomOptions = [{ name: "Bedroom", Icon: BedDouble, art: "bedroom" }, { name: "Kitchen", Icon: CookingPot, art: "kitchen" }, { name: "Hall", Icon: Sofa, art: "hall" }, { name: "Bathroom", Icon: Bath, art: "bathroom" }];
const emptyForm = { name: "", address: "", propertyType: "apartment", yearBuilt: "", rooms: [] };

export default function MyHome() {
  const { data, loading, error, refresh } = useCustomerData();
  const [editingId, setEditingId] = useState(null); const [showForm, setShowForm] = useState(false); const [form, setForm] = useState({ ...emptyForm }); const [saving, setSaving] = useState(false); const [message, setMessage] = useState(""); const [saveError, setSaveError] = useState("");
  const homes = data?.properties || [];
  function startAdd() { setEditingId(null); setForm({ ...emptyForm }); setMessage(""); setSaveError(""); setShowForm(true); }
  function startEdit(property) { setEditingId(property.id); setForm({ name: property.name, address: property.address, propertyType: property.property_type || "apartment", yearBuilt: property.year_built || "", rooms: property.rooms || [] }); setShowForm(true); setMessage(""); setSaveError(""); }
  function toggleRoom(room) { setForm((current) => ({ ...current, rooms: current.rooms.includes(room) ? current.rooms.filter((item) => item !== room) : [...current.rooms, room] })); }
  async function save(event) {
    event.preventDefault(); setSaving(true); setSaveError(""); setMessage("");
    const payload = { ...form, yearBuilt: form.yearBuilt || "" };
    try { if (editingId) await apiService.patch(`/customer/properties/${editingId}`, payload); else await apiService.post("/customer/properties", payload); await refresh(); setMessage(editingId ? "Home details updated." : "Your home has been saved."); setEditingId(null); setShowForm(false); setForm({ ...emptyForm }); }
    catch (e) { setSaveError(e.response?.data?.message || "We couldn't save your home. Please try again."); }
    finally { setSaving(false); }
  }
  function cancel() { setEditingId(null); setShowForm(false); setForm({ ...emptyForm }); setSaveError(""); }

  return <PageFrame eyebrow="Your account" title="My homes" description="Save the places where you need home services. Your details are private to your account.">
    {error && <div className="customer-notice" role="alert">{error}</div>}{message && <div className="customer-notice success" role="status">{message}</div>}
    {!loading && homes.length > 0 && <div className="my-home-toolbar"><div><strong>{homes.length} {homes.length === 1 ? "home" : "homes"} saved</strong><span>Choose a home when you book a service.</span></div><button type="button" className="portal-primary" onClick={startAdd}><Plus size={16}/>Add a home</button></div>}
    {showForm && <form className="app-panel home-setup-card" onSubmit={save}>
      <div className="home-setup-heading"><span className="home-setup-mark"><Building2 size={20}/></span><div><p className="customer-home-kicker">HOME DETAILS</p><h2>{editingId ? "Update this home" : "Set up your home"}</h2><p>Enter the address where you would like services.</p></div><button type="button" className="home-form-close" aria-label="Close form" onClick={cancel}><X size={18}/></button></div>
      {saveError && <div className="customer-notice" role="alert">{saveError}</div>}
      <div className="home-setup-fields"><label>Home name<input required maxLength={100} value={form.name} onChange={(e)=>setForm({...form,name:e.target.value})} placeholder="For example, My apartment"/></label><label>Home type<select value={form.propertyType} onChange={(e)=>setForm({...form,propertyType:e.target.value})}><option value="apartment">Apartment</option><option value="house">Independent house</option><option value="condo">Condominium</option><option value="home">Home</option><option value="other">Other</option></select></label><label className="home-field-address">Service address<input required maxLength={300} autoComplete="street-address" value={form.address} onChange={(e)=>setForm({...form,address:e.target.value})} placeholder="Flat, street, area, city, PIN code"/><small>We use this address to arrange your visits.</small></label><label>Year built <span className="home-optional">Optional</span><input type="number" min="1900" max={new Date().getFullYear()} value={form.yearBuilt} onChange={(e)=>setForm({...form,yearBuilt:e.target.value})} placeholder="Year"/></label></div>
      <fieldset className="home-room-field"><legend>Rooms in this home <span>Optional</span></legend><p>Select the rooms you may request service for.</p><div className="room-picker-grid">{roomOptions.map(({name,Icon,art})=><button type="button" aria-pressed={form.rooms.includes(name)} className={`room-choice-card ${form.rooms.includes(name)?"selected":""}`} onClick={()=>toggleRoom(name)} key={name}><span className={`room-mini-art ${art}`}><Icon size={22}/></span><strong>{name}</strong><span className="room-selected-mark">{form.rooms.includes(name)?"Added":"Add room"}</span></button>)}</div></fieldset>
      <div className="home-setup-footer"><button type="button" className="home-cancel-button" onClick={cancel}>Cancel</button><button type="submit" className="portal-primary" disabled={saving}><Save size={16}/>{saving ? "Saving…" : editingId ? "Save changes" : "Save home"}</button></div>
    </form>}
    {loading ? <div className="app-panel home-empty-state"><div className="home-empty-icon"><Home size={24}/></div><strong>Loading your homes…</strong></div> : homes.length ? <div className="saved-home-grid">{homes.map((property,index)=><article className="app-panel saved-home-card" key={property.id}><div className="saved-home-art"><Building2 size={28}/><span>{property.is_primary ? "Primary home" : `Home ${index+1}`}</span></div><div className="saved-home-content"><div className="saved-home-title"><div><h2>{property.name}</h2><span className="saved-home-type">{property.property_type || "Home"}</span></div><button type="button" className="home-edit-button" aria-label={`Edit ${property.name}`} onClick={()=>startEdit(property)}><Pencil size={15}/><span>Edit</span></button></div><p className="saved-home-address"><MapPin size={15}/>{property.address}</p><div className="saved-home-details"><span>{property.rooms?.length || 0} rooms added</span>{property.year_built && <span>Built {property.year_built}</span>}</div><div className="customer-room-chips">{(property.rooms || []).map((room)=>{const found=roomOptions.find((item)=>item.name===room);const Icon=found?.Icon||Home;return <span key={room}><Icon size={14}/>{room}</span>;})}{!property.rooms?.length && <span>No rooms added</span>}</div></div></article>)}</div> : !showForm && <section className="app-panel home-empty-state"><div className="home-empty-illustration"><Building2 size={32}/><span><Home size={15}/></span></div><p className="customer-home-kicker">GET STARTED</p><h2>Add your first home</h2><p>Save your address and the rooms you need help with. You can add more homes later.</p><button type="button" className="portal-primary" onClick={startAdd}><Plus size={16}/>Set up my home</button></section>}
  </PageFrame>;
}

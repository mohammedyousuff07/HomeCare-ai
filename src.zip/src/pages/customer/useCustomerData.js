import { useCallback, useEffect, useState } from "react";
import { apiService } from "../../services/api";
import { useAuth } from "../../context/useAuth";

export function useCustomerData() {
  const { user } = useAuth();
  const [data, setData] = useState(null); const [ownerId, setOwnerId] = useState(null); const [loading, setLoading] = useState(true); const [error, setError] = useState("");
  const refresh = useCallback(async () => {
    const accountId = user?.id;
    if (user?.role !== "customer" || !accountId) { setOwnerId(null); setLoading(false); return null; }
    setLoading(true);
    try { const { data: result } = await apiService.get("/customer/overview"); setData(result); setOwnerId(accountId); setError(""); return result; }
    catch (e) { setError(e.response?.data?.message || "Could not load your account data."); throw e; }
    finally { setLoading(false); }
  }, [user]);
  useEffect(() => { refresh().catch(() => {}); }, [refresh]);
  return { data: ownerId === user?.id ? data : null, loading, error, refresh };
}

import { useState } from "react";
import { BookOpen, CalendarDays, CheckCircle2, Home, MapPin, Plus, ShieldCheck } from "lucide-react";
import { Link } from "react-router-dom";
import PageFrame from "../../components/PageFrame";
import { useCustomerData } from "./useCustomerData";

export default function HomePassport() {
  const { data, loading, error } = useCustomerData();
  const homes = data?.properties || [];
  const [selectedId, setSelectedId] = useState("");
  const property = homes.find((home) => home.id === selectedId) || homes[0];
  const bookings = (data?.bookings || []).filter((booking) => property && (booking.property_id ? booking.property_id === property.id : booking.address === property.address)).sort((a,b) => new Date(b.scheduled_for)-new Date(a.scheduled_for));
  const warranties = (data?.warranties || []).filter((warranty) => bookings.some((booking) => booking.id === warranty.booking_id));
  const completed = bookings.filter((booking) => booking.status === "completed");

  return <PageFrame eyebrow="Your home records" title="Home passport" description="View the service history and coverage recorded for each saved home.">
    {error && <div className="customer-notice" role="alert">{error}</div>}
    {loading ? <section className="app-panel home-empty-state"><div className="home-empty-icon"><BookOpen size={24}/></div><strong>Loading your home passport…</strong></section> : property ? <>
      <section className="passport-card"><div className="passport-card-main"><span className="passport-icon"><BookOpen size={22}/></span><div><p className="customer-home-kicker">HOME PASSPORT</p><h2>{property.name}</h2><p><MapPin size={14}/>{property.address}</p></div></div><div className="passport-actions">{homes.length > 1 && <label className="passport-home-select"><span>Viewing home</span><select aria-label="Choose home" value={property.id} onChange={(event)=>setSelectedId(event.target.value)}>{homes.map((home)=><option key={home.id} value={home.id}>{home.name}</option>)}</select></label>}<Link className="passport-secondary-action" to="/my-home">Manage homes</Link><Link className="passport-primary-action" to="/bookings"><Plus size={15}/>Book service</Link></div></section>
      <section className="passport-summary-grid"><article><span className="passport-summary-icon blue"><CalendarDays size={17}/></span><small>Services for this home</small><strong>{bookings.length}</strong></article><article><span className="passport-summary-icon green"><CheckCircle2 size={17}/></span><small>Completed</small><strong>{completed.length}</strong></article><article><span className="passport-summary-icon gold"><ShieldCheck size={17}/></span><small>Warranties</small><strong>{warranties.length}</strong></article><article><span className="passport-summary-icon violet"><Home size={17}/></span><small>Rooms saved</small><strong>{property.rooms?.length || 0}</strong></article></section>
      <section className="passport-timeline-section"><div className="passport-section-heading"><div><p className="customer-home-kicker">HOME RECORD</p><h2>Service history</h2></div><Link to="/service-history">View all <span aria-hidden="true">→</span></Link></div>{bookings.length ? <div className="passport-timeline">{bookings.slice(0,10).map((booking)=><article className="passport-timeline-item" key={booking.id}><span className="passport-timeline-marker"><CalendarDays size={15}/></span><div className="passport-timeline-copy"><strong>{booking.service || booking.service_name || "Home service"}</strong><small>{new Date(booking.scheduled_for).toLocaleDateString([], {year:"numeric",month:"short",day:"numeric"})}{booking.room ? ` · ${booking.room}` : ""}</small></div><span className={`customer-status-pill ${booking.status}`}>{({pending:"Requested",confirmed:"Confirmed",in_progress:"In progress",completed:"Completed",cancelled:"Cancelled"})[booking.status] || booking.status}</span></article>)}</div> : <div className="passport-no-history"><CalendarDays size={21}/><div><strong>No services recorded for this home</strong><p>Bookings made using this saved home will appear here.</p></div><Link to="/bookings">Book a service</Link></div>}</section>
    </> : <section className="app-panel home-empty-state passport-empty-state"><div className="home-empty-illustration"><BookOpen size={30}/><span><Home size={15}/></span></div><p className="customer-home-kicker">YOUR HOME RECORD</p><h2>Add a home to get started</h2><p>Your Home Passport keeps this home’s bookings and warranties together. Save an address first, then select it when booking services.</p><Link className="portal-primary" to="/my-home"><Plus size={16}/>Add your home</Link></section>}
  </PageFrame>;
}

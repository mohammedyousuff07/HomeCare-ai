import { useCallback, useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Bath, BedDouble, CalendarDays, CookingPot, Home, MapPin, Plus, RotateCcw, Sofa } from "lucide-react";
import PageFrame from "../../components/PageFrame";
import StatusBadge from "../../components/StatusBadge";
import { useAuth } from "../../context/useAuth";
import { apiService } from "../../services/api";
import "./customer-bookings.css";

const localDateTime = (date) => {
  const pad = (number) => String(number).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
};
const initialSchedule = () => { const date = new Date(); date.setDate(date.getDate() + 1); date.setHours(10, 0, 0, 0); return localDateTime(date); };

function Bookings() {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const requestedProfessional = searchParams.get("professional") || "";
  const [bookings, setBookings] = useState([]);
  const [services, setServices] = useState([]);
  const [properties, setProperties] = useState([]);
  const [filter, setFilter] = useState("all");
  const [showForm, setShowForm] = useState(Boolean(requestedProfessional));
  const [serviceId, setServiceId] = useState("");
  const [professionalId, setProfessionalId] = useState(requestedProfessional);
  const [address, setAddress] = useState("");
  const [propertyId, setPropertyId] = useState("");
  const [scheduledFor, setScheduledFor] = useState(initialSchedule);
  const [notes, setNotes] = useState("");
  const [room, setRoom] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [reviewDrafts, setReviewDrafts] = useState({});
  const [reviewSaving, setReviewSaving] = useState("");
  const [bookingStep, setBookingStep] = useState(1);

  const load = useCallback(async () => {
    if (!user?.id) { setError("Your account session is missing. Please sign in again."); setLoading(false); return; }
    setLoading(true);
    try {
      const results = await Promise.allSettled([
        apiService.get("/bookings", { params: { customerId: user.id } }), apiService.get("/services"), apiService.get("/customer/properties"),
      ]);
      const [bookingResult, serviceResult, propertyResult] = results;
      if (bookingResult.status === "rejected") throw bookingResult.reason;
      setBookings(bookingResult.value.data.bookings || []);
      setServices(serviceResult.status === "fulfilled" ? serviceResult.value.data.services || [] : []);
      setProperties(propertyResult.status === "fulfilled" ? propertyResult.value.data.properties || [] : []);
      setError(serviceResult.status === "rejected" ? "Services could not be loaded. Your existing bookings are still available; try refreshing before creating a request." : "");
    } catch (e) { setError(e.response?.data?.message || "Could not load bookings. Check your connection and try again."); }
    finally { setLoading(false); }
  }, [user?.id]);
  useEffect(() => { load(); }, [load]);

  const filteredBookings = bookings.filter((booking) => filter === "all" || booking.status === filter);
  async function createBooking(event) {
    event.preventDefault(); setSaving(true); setError(""); setSuccess("");
    try {
      const { data } = await apiService.post("/bookings", { customerId: user.id, serviceId, professionalId: professionalId || undefined, propertyId: propertyId || undefined, address: address.trim(), scheduledFor: new Date(scheduledFor).toISOString(), notes: notes.trim(), room });
      if (data.booking) setBookings((current) => [data.booking, ...current.filter((booking) => booking.id !== data.booking.id)]);
      setSuccess(data.message || "Your service request has been saved."); setBookingStep(1);
      setAddress(""); setPropertyId(""); setNotes(""); setServiceId(""); setProfessionalId(""); setRoom(""); setScheduledFor(initialSchedule()); setShowForm(false);
      await load();
    } catch (e) { setError(e.response?.data?.message || "Could not create this service request."); }
    finally { setSaving(false); }
  }
  async function cancelBooking(booking) {
    if (!window.confirm("Cancel this service request?")) return;
    try { await apiService.patch(`/bookings/${booking.id}`, { status: "cancelled" }); await load(); }
    catch (e) { setError(e.response?.data?.message || "Could not cancel this booking."); }
  }
  async function submitReview(event, booking) {
    event.preventDefault(); const draft = reviewDrafts[booking.id] || { rating: 5, comment: "" }; setError(""); setReviewSaving(booking.id);
    try { const { data } = await apiService.post("/reviews", { bookingId: booking.id, rating: Number(draft.rating), comment: draft.comment }); setBookings((items) => items.map((item) => item.id === booking.id ? { ...item, review: data.review } : item)); }
    catch (e) { setError(e.response?.data?.message || "Could not submit your review."); }
    finally { setReviewSaving(""); }
  }
  const minimumSchedule = localDateTime(new Date(Date.now() + 60 * 60 * 1000));

  return <PageFrame eyebrow="Service activity" title="My Bookings" description="Create a service request and follow its progress from this account.">
    <div className="booking-toolbar"><div className="filter-tabs">{[["all", "All"], ["pending", "Requested"], ["confirmed", "Confirmed"], ["in_progress", "In progress"], ["completion_requested", "Needs approval"], ["completed", "Completed"], ["cancelled", "Cancelled"]].map(([value, title]) => <button className={filter === value ? "selected" : ""} onClick={() => setFilter(value)} key={value}>{title}</button>)}</div><button type="button" className="portal-primary" onClick={() => { setShowForm((visible) => !visible); setBookingStep(1); }}><Plus size={16} /> {showForm ? "Close form" : "New booking"}</button></div>
    {success && <div className="customer-booking-success" role="status">{success}</div>}
    {error && <div className="mb-4 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700" role="alert">{error}</div>}
    {showForm && <form className="app-panel customer-booking-form booking-wizard" onSubmit={createBooking}><div className="customer-booking-heading"><div><p className="section-label">BOOK A HOME SERVICE</p><h2>{bookingStep === 1 ? "What needs attention?" : bookingStep === 2 ? "Where and when should we visit?" : "Review your request"}</h2></div><p>Share only what the professional needs to prepare for your visit.</p></div>
      <div className="booking-wizard-progress">{["Choose service", "Visit details", "Review & send"].map((label, index) => <div className={`booking-wizard-step ${bookingStep === index + 1 ? "active" : bookingStep > index + 1 ? "done" : ""}`} key={label}><b>{bookingStep > index + 1 ? "✓" : index + 1}</b>{label}</div>)}</div>
      {bookingStep === 1 && <><label>Choose a service<select required value={serviceId} onChange={(e) => setServiceId(e.target.value)}><option value="">Choose a service</option>{services.map((service) => <option value={service.id} key={service.id}>{service.name} · ₹{Number(service.base_price).toLocaleString("en-IN")}</option>)}</select></label><fieldset className="room-choice-field"><legend>Which room needs attention?</legend><div className="room-picker-grid booking-room-grid">{[{ name: "Bedroom", Icon: BedDouble, art: "bedroom" }, { name: "Kitchen", Icon: CookingPot, art: "kitchen" }, { name: "Hall", Icon: Sofa, art: "hall" }, { name: "Bathroom", Icon: Bath, art: "bathroom" }, { name: "Other", Icon: Home, art: "other" }].map(({ name, Icon, art }) => <button type="button" className={`room-choice-card ${room === name ? "selected" : ""}`} onClick={() => setRoom(name)} key={name}><span className={`room-mini-art ${art}`}><Icon size={22}/></span><strong>{name}</strong><span className="room-selected-mark">{room === name ? "Selected" : "Choose"}</span></button>)}</div></fieldset><div className="booking-wizard-nav"><span>{serviceId ? `Starting price: ₹${Number(services.find((item) => item.id === serviceId)?.base_price || 0).toLocaleString("en-IN")}` : "Choose a service to see the starting price."}</span><button type="button" className="portal-primary" disabled={!serviceId || !room} onClick={() => setBookingStep(2)}>Continue</button></div></>}
      {bookingStep === 2 && <><div className="customer-booking-form-grid"><label>Service address{properties.length > 0 && <select aria-label="Use a saved home" value={propertyId} onChange={(e) => { const selected = e.target.value; const property = properties.find((item) => item.id === selected); setPropertyId(selected); if (property) setAddress(property.address); }}><option value="">Choose a saved home (optional)</option>{properties.map((property) => <option key={property.id} value={property.id}>{property.name}</option>)}</select>}<input required maxLength={300} value={address} onChange={(e) => { setAddress(e.target.value); const matches = properties.find((property) => property.address === e.target.value); setPropertyId(matches?.id || ""); }} placeholder="Flat, street, area, city, PIN code" /></label><label>Preferred date and time<input required type="datetime-local" min={minimumSchedule} value={scheduledFor} onChange={(e) => setScheduledFor(e.target.value)} /></label></div><div className="booking-wizard-nav"><button type="button" className="portal-secondary" onClick={() => setBookingStep(1)}>Back</button><button type="button" className="portal-primary" disabled={!address.trim() || new Date(scheduledFor) <= new Date()} onClick={() => setBookingStep(3)}>Review request</button></div></>}
      {bookingStep === 3 && <><div className="booking-wizard-summary"><div><small>Service</small><strong>{services.find((item) => item.id === serviceId)?.name || "—"}</strong></div><div><small>Room</small><strong>{room}</strong></div><div><small>Address</small><strong>{address}</strong></div><div><small>Visit time</small><strong>{new Date(scheduledFor).toLocaleString([], { dateStyle: "medium", timeStyle: "short" })}</strong></div><div><small>Starting price</small><strong>₹{Number(services.find((item) => item.id === serviceId)?.base_price || 0).toLocaleString("en-IN")}</strong></div></div><label className="customer-booking-notes">Notes for the professional <span>optional</span><textarea rows="3" maxLength="1000" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Access instructions or a short description" /></label>{!services.length && !loading && <p className="customer-booking-service-warning">No services are available right now. Please try again later.</p>}<div className="booking-wizard-nav"><button type="button" className="portal-secondary" onClick={() => setBookingStep(2)}>Back</button><button className="portal-primary" disabled={saving || loading || !services.length}>{saving ? "Sending request…" : "Confirm and send request"}</button></div><p className="customer-booking-footer booking-wizard-price-note">Any extra work or parts must be quoted and approved by you before the professional proceeds.</p></>}
    </form>}
    {loading ? <div className="app-panel customer-booking-empty">Loading your bookings…</div> : filteredBookings.length ? <div className="booking-list">{filteredBookings.map((booking) => <article className="booking-item" key={booking.id}><div className="booking-item-icon"><CalendarDays size={21} /></div><div className="booking-item-main"><div className="booking-item-title"><div><p className="section-label">{new Date(booking.scheduled_for).toLocaleString([], { dateStyle: "medium", timeStyle: "short" })}</p><h2>{booking.service || booking.service_name || "Home service"}</h2></div><StatusBadge status={booking.status} /></div><p className="booking-person"><MapPin size={14} /> {booking.room ? `${booking.room} · ` : ""}{booking.address}</p>{booking.notes && <p className="customer-booking-notes-text">{booking.notes}</p>}<div className="booking-item-foot"><strong>{booking.quoted_price == null ? "Price to be confirmed" : `₹${Number(booking.quoted_price).toLocaleString("en-IN")}`}</strong><span>{booking.professional || "Awaiting professional assignment"}</span><div className="booking-actions">{["pending", "confirmed"].includes(booking.status) && <button onClick={() => cancelBooking(booking)}><RotateCcw size={14} /> Cancel request</button>}<Link to={`/bookings/${booking.id}`}>Details</Link></div></div>{booking.status === "completed" && booking.professional && (booking.review ? <p className="booking-review-confirmation">You rated this service {booking.review.rating}/5 stars. Thank you.</p> : booking.payment?.status === "paid" ? <form className="booking-review-form" onSubmit={(event) => submitReview(event, booking)}><label>Rate your experience<select value={reviewDrafts[booking.id]?.rating || 5} onChange={(event) => setReviewDrafts((drafts) => ({ ...drafts, [booking.id]: { ...drafts[booking.id], rating: event.target.value } }))}><option value="5">5 — Excellent</option><option value="4">4 — Good</option><option value="3">3 — Okay</option><option value="2">2 — Poor</option><option value="1">1 — Very poor</option></select></label><textarea maxLength={1000} placeholder="Optional feedback for the professional" value={reviewDrafts[booking.id]?.comment || ""} onChange={(event) => setReviewDrafts((drafts) => ({ ...drafts, [booking.id]: { ...drafts[booking.id], comment: event.target.value } }))} /><button className="portal-secondary" disabled={reviewSaving === booking.id}>{reviewSaving === booking.id ? "Sending…" : "Submit review"}</button></form> : <p className="booking-review-confirmation">Confirm payment to unlock your rating.</p>)}</div></article>)}</div> : <div className="app-panel customer-booking-empty"><CalendarDays size={25} /><strong>{bookings.length ? "No bookings in this status" : "No bookings yet"}</strong><p>{bookings.length ? "Choose another filter to see your requests." : "Create your first service request and it will appear here."}</p>{!showForm && <button className="portal-secondary" onClick={() => setShowForm(true)}>Create a booking</button>}</div>}
  </PageFrame>;
}

export default Bookings;

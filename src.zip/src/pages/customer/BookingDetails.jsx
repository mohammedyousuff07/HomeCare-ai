import { useCallback, useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Check, Clock3, MapPin } from "lucide-react";
import PageFrame from "../../components/PageFrame";
import BookingMessages from "../../components/BookingMessages";
import BookingPaymentPanel from "../../components/BookingPaymentPanel";
import { apiService } from "../../services/api";

const stages = ["pending", "confirmed", "in_progress", "completion_requested", "completed"];
const stageLabel = (stage) => ({ in_progress: "In progress", completion_requested: "Needs your approval" }[stage] || stage.replaceAll("_", " "));

export default function BookingDetails() {
  const { id } = useParams();
  const [booking, setBooking] = useState(null); const [error, setError] = useState(""); const [message, setMessage] = useState(""); const [loading, setLoading] = useState(true); const [saving, setSaving] = useState(false); const [professionalLocation, setProfessionalLocation] = useState(null);
  const load = useCallback(async () => {
    try { const { data } = await apiService.get("/bookings"); const record = (data.bookings || []).find((item) => item.id === id); if (record) setBooking(record); else setError("We couldn’t find that booking in your account."); }
    catch (e) { setError(e.response?.data?.message || "Could not load this booking."); }
    finally { setLoading(false); }
  }, [id]);
  useEffect(() => { load(); const timer = window.setInterval(load, 30000); return () => window.clearInterval(timer); }, [load]);
  useEffect(() => {
    if (booking?.status !== "in_progress") { setProfessionalLocation(null); return undefined; }
    let active = true;
    const refreshLocation = async () => { try { const { data } = await apiService.get(`/bookings/${id}/location`); if (active) setProfessionalLocation(data.location || null); } catch { if (active) setProfessionalLocation(null); } };
    refreshLocation(); const timer = window.setInterval(refreshLocation, 20000);
    return () => { active = false; window.clearInterval(timer); };
  }, [booking?.status, id]);
  async function approveCompletion() {
    setSaving(true); setError("");
    try { await apiService.patch(`/bookings/${id}`, { status: "completed" }); await load(); setMessage("Work approved. Choose a payment method below; you can rate the professional after payment is confirmed."); }
    catch (e) { setError(e.response?.data?.message || "Could not approve completion."); }
    finally { setSaving(false); }
  }
  const amount = booking?.payment?.amount ?? booking?.final_price ?? booking?.quoted_price;
  return <PageFrame eyebrow={booking ? `Booking HC-${booking.id.slice(-6)}` : "Your booking"} title={booking?.service || booking?.service_name || "Booking details"} description="See the next step, message your professional, and keep all service details together.">
    {error && <div className="customer-notice" role="alert">{error}</div>}
    {message && <div className="customer-booking-success" role="status">{message}</div>}
    {loading ? <div className="app-panel customer-empty-card">Loading your booking…</div> : booking && <>
      <section className="app-panel customer-booking-detail">
        <div className="customer-detail-top"><div><p className="section-label">{booking.scheduled_for ? new Date(booking.scheduled_for).toLocaleString([], { dateStyle: "full", timeStyle: "short" }) : "Date to be arranged"}</p><h2>{booking.professional || "Waiting for professional assignment"}</h2><p><MapPin size={15}/> {booking.room ? `${booking.room} · ` : ""}{booking.address}</p></div><span className={`status-badge ${booking.status === "completed" ? "green" : ["pending", "completion_requested"].includes(booking.status) ? "amber" : "blue"}`}>{stageLabel(booking.status)}</span></div>
        <div className="customer-detail-facts"><div><small>Service</small><strong>{booking.service || booking.service_name || "Home service"}</strong></div><div><small>Agreed starting price</small><strong>{booking.quoted_price == null ? "To be confirmed" : `₹${Number(booking.quoted_price).toLocaleString("en-IN")}`}</strong></div><div><small>Request sent</small><strong>{booking.created_at ? new Date(booking.created_at).toLocaleDateString() : "—"}</strong></div></div>
        {booking.notes && <div className="customer-detail-notes"><strong>Your visit notes</strong><p>{booking.notes}</p></div>}
        {booking.status === "in_progress" && <section className="completion-approval"><h2>Professional location</h2>{professionalLocation ? <><p>Last updated {new Date(professionalLocation.updated_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}. Location refreshes while the job is active.</p><a className="portal-secondary" target="_blank" rel="noreferrer" href={`https://www.openstreetmap.org/?mlat=${professionalLocation.latitude}&mlon=${professionalLocation.longitude}#map=16/${professionalLocation.latitude}/${professionalLocation.longitude}`}>View on map</a></> : <p>The professional has not shared a current location.</p>}</section>}
        <div className="booking-timeline">{stages.map((stage, index) => { const done = stages.indexOf(booking.status) >= index; return <span className={done ? "done" : ""} key={stage}>{done ? <Check size={13} /> : <Clock3 size={13} />}{stageLabel(stage)}</span>; })}</div>
        {booking.status === "completion_requested" && <section className="completion-approval"><h2>Did the work finish as agreed?</h2><p>Approve only after you’ve checked the work. If anything is wrong, send a complaint to the admin team and keep the job under review.</p><div className="customer-completion-actions"><button className="completion-approve-button" onClick={approveCompletion} disabled={saving}><Check size={16}/>{saving ? "Approving…" : "Approve completed work"}</button><Link className="completion-complaint-button" to={`/report-problem?booking=${booking.id}`}><span>×</span>Raise a complaint</Link></div></section>}
        {booking.status === "completed" && <BookingPaymentPanel bookingId={id} payment={booking.payment} amount={amount} onUpdate={(payment) => setBooking((current) => ({ ...current, payment }))} onMessage={setMessage} onError={setError}/>}
        {booking.status !== "completed" && booking.status !== "cancelled" && booking.status !== "completion_requested" && <Link className="portal-secondary report-booking-link" to={`/report-problem?booking=${booking.id}`}>Report a problem to admin</Link>}
      </section>
      <BookingMessages bookingId={booking.id} otherParty={booking.professional || "your professional"} enabled={Boolean(booking.professional_id)}/>
      {booking.status === "completed" && booking.payment?.status === "paid" && <div className="completion-approved-note">Payment confirmed. Rate your professional from <Link to="/bookings">My Bookings</Link>.</div>}
      <Link className="panel-link" to="/bookings"><ArrowLeft size={15}/> Back to my bookings</Link>
    </>}
  </PageFrame>;
}

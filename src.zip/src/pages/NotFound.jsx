import { Link } from "react-router-dom";
import { ArrowLeft, Home } from "lucide-react";

function NotFound() {
  return <div className="portal-shell flex min-h-screen items-center justify-center px-5"><div className="auth-panel text-center"><span className="app-logo mx-auto"><Home size={20} /></span><p className="section-label mt-7">Page not found</p><h1 className="mt-2 text-3xl font-bold text-portal-navy">That page is not here.</h1><p className="mt-3 text-sm text-portal-muted">Return to your home overview to continue managing your property.</p><Link to="/dashboard" className="portal-primary mt-7"><ArrowLeft size={16} /> Back to dashboard</Link></div></div>;
}

export default NotFound;

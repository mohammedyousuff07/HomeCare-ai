import { useState } from "react";
import { Edit3, UserRound } from "lucide-react";
import PageFrame from "../components/PageFrame";
import { useAuth } from "../context/useAuth";
import { apiService } from "../services/api";

export default function AccountProfile() {
  const { user, refreshAccount } = useAuth();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user?.name || "");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function save(event) {
    event.preventDefault();
    setSaving(true); setError(""); setMessage("");
    try {
      await apiService.patch("/account/profile", { name });
      await refreshAccount();
      setEditing(false);
      setMessage("Your name has been updated.");
    } catch (e) {
      setError(e.response?.data?.message || "Could not update your name.");
    } finally { setSaving(false); }
  }

  const initials = (user?.name || "U").split(" ").filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
  return <PageFrame eyebrow="Account" title="My profile" description="View and update the name shown on your HomeCare account.">
    {error && <div className="professional-data-notice" role="alert">{error}</div>}
    {message && <div className="professional-data-notice" role="status">{message}</div>}
    <section className="app-panel" style={{ maxWidth: 620, padding: 24 }}>
      <div className="profile-identity" style={{ padding: 0, margin: 0 }}>
        <div className="profile-avatar">{initials || "U"}</div>
        <div><p className="section-label">{user?.role || "Account"}</p><h2 style={{ color: "#17324d", marginTop: 5 }}>{user?.name}</h2><p>{user?.email}</p></div>
        {!editing && <button className="portal-secondary profile-edit" onClick={() => { setName(user?.name || ""); setEditing(true); }}><Edit3 size={14} /> Edit name</button>}
      </div>
      {editing && <form className="profile-edit-form" onSubmit={save}>
        <label>Your name<input required autoComplete="name" maxLength={100} value={name} onChange={(event) => setName(event.target.value)} /></label>
        <div className="flex gap-2"><button className="portal-primary" disabled={saving}>{saving ? "Saving…" : "Save name"}</button><button type="button" className="portal-secondary" disabled={saving} onClick={() => { setName(user?.name || ""); setEditing(false); }}>Cancel</button></div>
      </form>}
      {!editing && <p className="professional-empty" style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 20 }}><UserRound size={16} /> Your name appears on your HomeCare profile.</p>}
    </section>
  </PageFrame>;
}

import CustomerLayout from "./CustomerLayout";
function ProfessionalLayout({ children }) { return <CustomerLayout>{children}</CustomerLayout>; }
export default ProfessionalLayout;

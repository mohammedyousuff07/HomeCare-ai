import CustomerLayout from "./CustomerLayout";
function AdminLayout({ children }) { return <CustomerLayout>{children}</CustomerLayout>; }
export default AdminLayout;

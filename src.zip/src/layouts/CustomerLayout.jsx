import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
function CustomerLayout({ children }) { return <div className="portal-shell min-h-screen"><Navbar /><div className="flex"><Sidebar /><main className="min-w-0 flex-1">{children}</main></div></div>; }
export default CustomerLayout;

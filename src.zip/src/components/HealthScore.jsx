function HealthScore({ score = 86 }) {
  return (
    <div className="app-panel health-score-panel">
      <div className="flex items-start justify-between">
        <div>
          <p className="panel-label">
            Home Health Score
          </p>

          <div className="mt-2 flex items-end gap-2">
            <span className="score-number">
              {score}
            </span>

            <span className="score-denominator">
              /100
            </span>
          </div>
        </div>

        <div className="score-status">
          Good
        </div>
      </div>

      <div className="score-progress">
        <div
          className="score-progress-value"
          style={{ width: `${score}%` }}
        />
      </div>

      <p className="panel-note">
        Your home is currently in good condition.
      </p>
    </div>
  );
}

export default HealthScore;
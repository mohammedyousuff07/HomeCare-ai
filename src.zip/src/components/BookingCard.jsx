import { ArrowRight, CalendarDays } from "lucide-react";
import { Link } from "react-router-dom";
import StatusBadge from "./StatusBadge";

function BookingCard({ booking }) {
	return <div className="booking-card"><div className="booking-card-icon"><CalendarDays size={20} /></div><div className="booking-card-copy"><strong>{booking.service}</strong><small>{booking.professional} · {booking.date} · {booking.time}</small></div><div className="booking-card-meta"><StatusBadge status={booking.status} /><Link to={`/bookings/${booking.id}`} aria-label={`View ${booking.service}`}><ArrowRight size={17} /></Link></div></div>;
}

export default BookingCard;

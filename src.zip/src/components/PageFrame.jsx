import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import RoleActionBanner from "./RoleActionBanner";

function PageFrame({ eyebrow, title, description, actions, children }) {
  return <div className="portal-shell min-h-screen"><Navbar /><div className="flex"><Sidebar /><main className="flex-1 p-5 lg:p-8"><div className="mx-auto max-w-6xl"><RoleActionBanner/><header className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-start"><div><p className="section-label">{eyebrow}</p><h1 className="mt-2 text-3xl font-bold text-portal-navy">{title}</h1><p className="mt-2 text-sm text-portal-muted">{description}</p></div>{actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}</header>{children}</div></main></div></div>;
}

export default PageFrame;

import { Link } from "react-router-dom";
import { Activity, ArrowRight, BriefcaseBusiness, ClipboardList, Clock3, ShieldCheck, Users, WalletCards } from "lucide-react";
import PageFrame from "./PageFrame";

const professionalMetrics = [
  ["Today's jobs", "4", Activity], ["Pending requests", "7", ClipboardList], ["On-time rate", "94%", Clock3], ["This month", "₹18,450", WalletCards],
];
const adminMetrics = [
  ["Customers", "2,408", Users], ["Professionals", "186", ShieldCheck], ["Active bookings", "64", ClipboardList], ["Pending reviews", "12", Clock3],
];

function RolePage({ role = "professional", title, description, children }) {
  const isProfessional = role === "professional";
  const metrics = isProfessional ? professionalMetrics : adminMetrics;
  const links = isProfessional ? [["Jobs", "/professional/jobs"], ["Profile", "/professional/profile"], ["Availability", "/professional/availability"], ["Earnings", "/professional/earnings"]] : [["Users", "/admin/users"], ["Professionals", "/admin/professionals"], ["Bookings", "/admin/bookings"], ["Analytics", "/admin/analytics"]];
  return <PageFrame eyebrow={isProfessional ? "Professional portal" : "Administration"} title={title} description={description}><div className="role-metric-grid">{metrics.map(([label, value, Icon]) => <div className="role-metric" key={label}><span><Icon size={18} /></span><small>{label}</small><strong>{value}</strong></div>)}</div><div className="role-content-grid"><div className="app-panel role-list-panel"><div className="role-panel-heading"><div><p className="section-label">Workspace</p><h2>{isProfessional ? "Your work at a glance" : "Platform overview"}</h2></div><BriefcaseBusiness size={19} className="text-[#1769a5]" /></div>{children || <div className="role-empty"><p>{isProfessional ? "You have new service requests ready to review." : "Your platform activity is up to date."}</p><Link to={links[0][1]} className="panel-link">Open workspace <ArrowRight size={15} /></Link></div>}</div><div className="role-links"><p className="section-label">Quick access</p>{links.map(([label, path]) => <Link className="role-link" to={path} key={path}><span>{label}</span><ArrowRight size={15} /></Link>)}</div></div></PageFrame>;
}
export default RolePage;

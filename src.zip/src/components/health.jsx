import HealthScore from "./HealthScore";

export default HealthScore;

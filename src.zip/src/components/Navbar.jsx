import { Link } from "react-router-dom";
import { Bell, CalendarDays, Home, Moon, Search, Sun, Wrench } from "lucide-react";
import { ROLE_DASHBOARD_MAP, useAuth } from "../context/useAuth";

function getInitials(name = "User") {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() || "")
    .join("") || "U";
}

function Navbar() {
  const { user, logout, theme, toggleTheme } = useAuth();
  const role = user?.role || "customer";
  const profileName = user?.name || "Guest";
  const roleIdentity = {
    customer: { title: "Customer", emoji: "🏠" },
    professional: { title: "Professional", emoji: "🧰" },
    admin: { title: "Admin", emoji: "🛡️" },
  }[role] || { title: "User", emoji: "👤" };
  const dashboardPath = ROLE_DASHBOARD_MAP[role] || "/dashboard";
  const profilePath = role === "professional" ? "/professional/profile" : role === "admin" ? "/admin/profile" : "/profile";
  const notificationsPath = role === "professional"
    ? "/professional/notifications"
    : role === "admin"
      ? "/admin/complaints"
      : "/notifications";
  const quickLinks = role === "customer"
    ? [{ label: "Home", path: "/dashboard", icon: Home }, { label: "Report", path: "/report-problem", icon: Wrench }, { label: "Bookings", path: "/bookings", icon: CalendarDays }]
    : [];

  return (
    <nav className="app-navbar">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
        <Link to={dashboardPath} className="app-brand">
          <div className="app-logo">
            <Home size={22} />
          </div>
          <span><strong>HomeCare</strong> <em>AI</em><small>Home management</small></span>
        </Link>

        <div className="flex items-center gap-3">
          <button type="button" className="theme-toggle" onClick={toggleTheme} aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`} title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}>{theme === "dark" ? <Sun size={18}/> : <Moon size={18}/>}<span>{theme === "dark" ? "Light" : "Dark"}</span></button>
          <button className="app-search" aria-label="Search"><Search size={18} /></button>
          <Link to={notificationsPath} className="app-bell" aria-label="Notifications">
            <Bell size={20} />
          </Link>

          {user && <span className={`app-role-badge app-role-${role}`} title={`Logged in as ${roleIdentity.title}`} aria-label={`Logged in as ${roleIdentity.title}`}><span aria-hidden="true">{roleIdentity.emoji}</span>{roleIdentity.title}</span>}
          {user ? <Link to={profilePath} className="app-avatar" title="Open your profile" aria-label="Open your profile">{getInitials(profileName)}</Link> : <div className="app-avatar" title={profileName}>{getInitials(profileName)}</div>}

          {user && (
            <button type="button" className="portal-secondary" onClick={logout}>
              Logout
            </button>
          )}
        </div>
      </div>
      {quickLinks.length > 0 && (
        <div className="mobile-quick-nav">
          {quickLinks.map(({ label, path, icon: Icon }) => (
            <Link key={path} to={path} className="mobile-quick-link"><Icon size={16} /><span>{label}</span></Link>
          ))}
          <Link to={notificationsPath} className="mobile-quick-link"><Bell size={16} /><span>Alerts</span></Link>
        </div>
      )}
    </nav>
  );
}

export default Navbar;

import { useState } from "react";
import { Banknote, CheckCircle2, CreditCard, Landmark, Smartphone } from "lucide-react";
import { apiService } from "../services/api";
import "./booking-flow.css";

const choices = [
  { id: "cash", title: "Cash", hint: "Pay the professional directly", Icon: Banknote },
  { id: "upi", title: "UPI", hint: "Pay externally using UPI", Icon: Smartphone },
  { id: "card", title: "Card", hint: "Use the professional’s card terminal", Icon: CreditCard },
  { id: "netbanking", title: "Net banking", hint: "Pay using your bank’s own app/site", Icon: Landmark },
];
const label = (value) => choices.find((choice) => choice.id === value)?.title || value || "Payment";

export default function BookingPaymentPanel({ bookingId, payment, amount, onUpdate, onMessage, onError }) {
  const [method, setMethod] = useState("upi"); const [saving, setSaving] = useState(false);
  async function reportPayment() {
    setSaving(true); onError("");
    try { const { data } = await apiService.post(`/payments/${bookingId}/report`, { method }); onUpdate(data.payment); onMessage(data.message); }
    catch (e) { onError(e.response?.data?.message || "Could not record this payment method."); }
    finally { setSaving(false); }
  }
  return <section className="booking-payment-panel app-panel">
    <div className="booking-payment-heading"><span><CreditCard size={18}/></span><div><p className="section-label">PAYMENT APPROVAL</p><h2>Approve and record payment</h2></div><strong className="booking-payment-total">₹{Number(amount || 0).toLocaleString("en-IN")}</strong></div>
    {payment?.status === "paid" ? <div className="booking-payment-confirmed"><CheckCircle2 size={19}/><div><strong>Payment confirmed</strong><p>{label(payment.payment_method)} · Confirmed {payment.paid_at ? new Date(payment.paid_at).toLocaleString() : ""}</p></div></div> : ["cash_reported", "method_reported"].includes(payment?.status) ? <div className="booking-payment-pending"><span className="booking-payment-pending-mark">…</span><div><strong>{label(payment.payment_method)} reported</strong><p>Waiting for the professional to confirm they received it.</p></div></div> : payment?.status === "due" ? <>
      <div className="booking-payment-options" role="radiogroup" aria-label="Choose a payment method">{choices.map(({ id, title, hint, Icon }) => <button type="button" role="radio" aria-checked={method === id} className={`booking-payment-choice ${method === id ? "selected" : ""}`} onClick={() => setMethod(id)} key={id}><Icon size={19}/><strong>{title}</strong><small>{hint}</small><span className="booking-payment-radio"/></button>)}</div>
      <p className="booking-payment-disclaimer">HomeCare records your selected method; it does not process online payments. Pay directly using the agreed method, then report it here. Never share a PIN, OTP, or full card number in chat.</p>
      <button className="portal-primary booking-payment-submit" onClick={reportPayment} disabled={saving}>{saving ? "Saving…" : `I’ve paid with ${label(method)}`}</button>
    </> : <div className="booking-payment-disclaimer">A payment record is not available yet. Refresh this booking or contact support.</div>}
  </section>;
}

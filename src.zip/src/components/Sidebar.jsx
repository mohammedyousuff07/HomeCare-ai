import { NavLink } from "react-router-dom";
import {
  AlertTriangle,
  BarChart3,
  BookOpen,
  BriefcaseBusiness,
  CalendarDays,
  ClipboardList,
  Code2,
  FileText,
  Gauge,
  History,
  Home,
  LayoutDashboard,
  MessageSquareText,
  Settings,
  ShieldCheck,
  Star,
  Users,
  WalletCards,
  Wrench,
} from "lucide-react";
import { useAuth } from "../context/useAuth";

const linksByRole = {
  customer: [
    { name: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
    { name: "My Home", path: "/my-home", icon: Home },
    { name: "Report Problem", path: "/report-problem", icon: Wrench },
    { name: "Professionals", path: "/professionals", icon: Users },
    { name: "Bookings", path: "/bookings", icon: CalendarDays },
    { name: "Maintenance", path: "/maintenance", icon: Gauge },
    { name: "Service History", path: "/service-history", icon: History },
    { name: "Home Passport", path: "/home-passport", icon: BookOpen },
    { name: "Warranty", path: "/warranty", icon: ShieldCheck },
    { name: "Notifications", path: "/notifications", icon: MessageSquareText },
    { name: "Emergency", path: "/emergency", icon: AlertTriangle },
  ],
  professional: [
    { name: "Dashboard", path: "/professional/dashboard", icon: LayoutDashboard },
    { name: "Jobs", path: "/professional/jobs", icon: BriefcaseBusiness },
    { name: "Profile", path: "/professional/profile", icon: Users },
    { name: "Availability", path: "/professional/availability", icon: CalendarDays },
    { name: "Earnings", path: "/professional/earnings", icon: WalletCards },
    { name: "Reviews", path: "/professional/reviews", icon: Star },
    { name: "Notifications", path: "/professional/notifications", icon: MessageSquareText },
  ],
  admin: [
    { name: "Dashboard", path: "/admin/dashboard", icon: LayoutDashboard },
    { name: "Users", path: "/admin/users", icon: Users },
    { name: "Professionals", path: "/admin/professionals", icon: BriefcaseBusiness },
    { name: "Bookings", path: "/admin/bookings", icon: CalendarDays },
    { name: "Categories", path: "/admin/categories", icon: ClipboardList },
    { name: "Complaints", path: "/admin/complaints", icon: MessageSquareText },
    { name: "Warranties", path: "/admin/warranties", icon: ShieldCheck },
    { name: "Maintenance", path: "/admin/maintenance", icon: Wrench },
    { name: "AI Settings", path: "/admin/ai-settings", icon: Settings },
    { name: "Analytics", path: "/admin/analytics", icon: BarChart3 },
    { name: "Evaluation Report", path: "/admin/evaluation-report", icon: Code2 },
    { name: "Knowledge Base", path: "/admin/knowledge-base", icon: BookOpen },
    { name: "Audit Logs", path: "/admin/audit-logs", icon: FileText },
  ],
};

const roleTitle = {
  customer: "Your home",
  professional: "Service workspace",
  admin: "Operations",
};

function Sidebar() {
  const { user } = useAuth();
  const role = user?.role || "customer";
  const links = linksByRole[role] || linksByRole.customer;

  return (
    <aside className="app-sidebar hidden min-h-[calc(100vh-73px)] w-64 lg:block">
      <div className="p-4">
        <p className="sidebar-label">{roleTitle[role] || "Navigation"}</p>

        <div className="space-y-1">
          {links.map((link) => {
            const Icon = link.icon;

            return (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) =>
                  `app-nav-link flex items-center gap-3 ${isActive ? "active" : ""}`
                }
              >
                <Icon size={18} />
                {link.name}
              </NavLink>
            );
          })}
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;

function StatusBadge({ status }) {
  const styles = {
    CONFIRMED: "blue", confirmed: "blue",
    IN_PROGRESS: "amber", in_progress: "amber",
    completion_requested: "amber",
    COMPLETED: "green", completed: "green",
    CANCELLED: "red", cancelled: "red",
    REQUESTED: "slate", pending: "slate",
  };

  return (
    <span
      className={`status-badge ${styles[status] || "slate"}`}
    >
      {{ completion_requested: "Awaiting customer approval" }[status] || status?.replaceAll("_", " ")}
    </span>
  );
}

export default StatusBadge;

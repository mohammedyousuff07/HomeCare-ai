import { ArrowRight, Wrench } from "lucide-react";
import { Link } from "react-router-dom";

function ServiceCard({ title, description, path = "/report-problem" }) {
	return <Link className="service-card" to={path}><span className="service-card-icon"><Wrench size={19} /></span><span><strong>{title}</strong><small>{description}</small></span><ArrowRight size={16} /></Link>;
}

export default ServiceCard;

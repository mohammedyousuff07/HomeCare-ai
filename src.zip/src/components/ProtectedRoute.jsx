import { Navigate, Outlet, useLocation } from "react-router-dom";
import { ROLE_DASHBOARD_MAP, useAuth } from "../context/useAuth";

function ProtectedRoute({ roles }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return <div className="portal-shell grid min-h-screen place-items-center text-sm text-slate-500">Checking your sign-in…</div>;

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  if (user.role === "professional" && user.professional_status !== "approved" && location.pathname !== "/professional/application") {
    return <Navigate to="/professional/application" replace />;
  }

  if (roles && !roles.includes(user.role)) {
    return <Navigate to={ROLE_DASHBOARD_MAP[user.role] || "/login"} replace />;
  }

  return <Outlet />;
}

export default ProtectedRoute;

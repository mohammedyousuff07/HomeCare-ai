import { Link } from "react-router-dom";
import {
  ShieldCheck,
  MapPin,
  ArrowRight,
} from "lucide-react";

function ProfessionalCard({ professional }) {
  return (
    <div className="app-panel professional-card">
      <div className="flex items-start gap-4">

        <div className="professional-avatar">
          {professional.name.charAt(0)}
        </div>

        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className="card-title">
              {professional.name}
            </h3>

            {professional.verified && (
              <ShieldCheck
                size={17}
                className="text-green-600"
              />
            )}
          </div>

          <p className="card-muted mt-1 text-sm">{professional.skill}</p>
        </div>
      </div>

      <div className="professional-metrics mt-5 grid grid-cols-2 gap-3 text-sm">

        <div className="flex items-center gap-2">
          <MapPin size={16} />
          {professional.service_area || "Service area not provided"}
        </div>

        <div>
          <span className="font-semibold">
            {professional.experience || "Experience not provided"}
          </span>{" "}
        </div>

      </div>

      <Link
        to={`/professionals/${professional.id}`}
        className="card-action mt-5 flex items-center justify-center gap-2"
      >
        View Professional
        <ArrowRight size={16} />
      </Link>
    </div>
  );
}

export default ProfessionalCard;

import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AlertTriangle, Bell, Check, CircleX, CreditCard } from "lucide-react";
import { useAuth } from "../context/useAuth";
import { apiService } from "../services/api";
import "./booking-flow.css";

export default function RoleActionBanner() {
  const { user } = useAuth(); const navigate = useNavigate(); const [notice, setNotice] = useState(null); const [busy, setBusy] = useState(false); const [error, setError] = useState("");
  const refresh = useCallback(async () => {
    if (!user) return;
    try {
      const { data } = user.role === "customer" ? await apiService.get("/customer/overview") : user.role === "professional" ? await apiService.get("/professional/notifications") : await apiService.get("/admin/notifications");
      const notes = data.notifications || [];
      const priority = user.role === "customer" ? ["booking_completion_requested", "payment_due", "professional_complaint_response"] : user.role === "professional" ? ["booking_assigned", "payment_method_reported"] : ["complaint_received", "professional_complaint_response", "booking_unassigned"];
      setNotice(notes.find((item) => !item.read_at && priority.includes(item.type)) || null); setError("");
    } catch { setError("Could not refresh account alerts."); }
  }, [user]);
  useEffect(() => { refresh(); const timer = window.setInterval(refresh, 20000); return () => window.clearInterval(timer); }, [refresh]);
  if (!notice) return null;
  async function markRead() { try { await apiService.patch(`/notifications/${notice.id}`, { read: true }); setNotice(null); } catch { /* Keep the alert visible if it could not be acknowledged. */ } }
  async function approve() {
    if (!notice.booking_id) return;
    setBusy(true); setError("");
    try { await apiService.patch(`/bookings/${notice.booking_id}`, { status: "completed" }); await markRead(); navigate(`/bookings/${notice.booking_id}`); }
    catch (e) { setError(e.response?.data?.message || "Could not approve this work yet."); setBusy(false); }
  }
  async function reportProblem() { await markRead(); navigate(`/report-problem?booking=${notice.booking_id}`); }
  const isCompletion = notice.type === "booking_completion_requested";
  const isPayment = notice.type === "payment_due";
  const isJob = user.role === "professional" && notice.type === "booking_assigned";
  const title = isCompletion ? "Your professional marked this job complete" : isPayment ? "Payment is ready for your approval" : isJob ? "New job request" : notice.title || "New HomeCare alert";
  return <aside className={`role-action-banner ${user.role === "admin" ? "admin" : user.role === "professional" ? "professional" : "customer"}`} role="status"><span className="role-action-banner-icon">{isCompletion ? <Check size={19}/> : isPayment ? <CreditCard size={19}/> : user.role === "admin" ? <AlertTriangle size={19}/> : <Bell size={19}/>}</span><div className="role-action-banner-copy"><strong>{title}</strong><p>{notice.message}</p>{error && <small role="alert">{error}</small>}</div><div className="role-action-banner-actions">{isCompletion ? <><button className="role-action-approve" onClick={approve} disabled={busy}><Check size={15}/>{busy ? "Approving…" : "Approve work"}</button><button className="role-action-complain" onClick={reportProblem} disabled={busy}><CircleX size={15}/>Report a problem</button></> : <button className="role-action-open" onClick={async () => { await markRead(); navigate(user.role === "admin" ? "/admin/complaints" : user.role === "professional" && notice.booking_id ? `/professional/jobs/${notice.booking_id}` : isPayment ? `/bookings/${notice.booking_id}` : "/notifications"); }}><Bell size={15}/>{user.role === "admin" ? "Review complaint" : isPayment ? "Review payment" : isJob ? "Review job" : "View update"}</button>}</div></aside>;
}

import { useCallback, useEffect, useRef, useState } from "react";
import { MessageCircle, Send } from "lucide-react";
import { useAuth } from "../context/useAuth";
import { apiService } from "../services/api";
import "./booking-flow.css";

export default function BookingMessages({ bookingId, otherParty = "the other person", enabled = true }) {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);
  const bottom = useRef(null);
  const refresh = useCallback(async () => {
    if (!enabled || !bookingId) return;
    try { const { data } = await apiService.get(`/bookings/${bookingId}/messages`); setItems(data.messages || []); setError(""); }
    catch (e) { setError(e.response?.data?.message || "Messages are temporarily unavailable."); }
  }, [bookingId, enabled]);
  useEffect(() => { refresh(); if (!enabled) return undefined; const timer = window.setInterval(refresh, 8000); return () => window.clearInterval(timer); }, [refresh, enabled]);
  useEffect(() => { bottom.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [items]);
  async function send(event) {
    event.preventDefault(); const text = draft.trim(); if (!text || sending) return;
    setSending(true); setError("");
    try { const { data } = await apiService.post(`/bookings/${bookingId}/messages`, { message: text }); setItems((current) => [...current, data.message]); setDraft(""); }
    catch (e) { setError(e.response?.data?.message || "Could not send your message."); }
    finally { setSending(false); }
  }
  return <section className="booking-conversation app-panel" aria-label="Booking messages">
    <div className="booking-conversation-heading"><span><MessageCircle size={18}/></span><div><h2>Booking messages</h2><p>Coordinate this visit with {otherParty}. Keep payment and changes in the app.</p></div></div>
    {!enabled ? <div className="booking-conversation-locked">Messaging opens after a professional accepts this request.</div> : <>
      {error && <p className="booking-conversation-error" role="alert">{error}</p>}
      <div className="booking-message-list" aria-live="polite">{items.length ? items.map((item) => { const mine = String(item.sender_id) === String(user?.id); return <article className={`booking-message ${mine ? "mine" : "theirs"}`} key={item.id}><span>{mine ? "You" : item.sender_name || otherParty}</span><p>{item.message}</p><time>{new Date(item.created_at).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</time></article>; }) : !error && <div className="booking-conversation-empty">No messages yet. Send a note about access, timing, or the service.</div>}<div ref={bottom}/></div>
      <form className="booking-message-compose" onSubmit={send}><label className="sr-only" htmlFor={`booking-message-${bookingId}`}>Write a message</label><textarea id={`booking-message-${bookingId}`} maxLength={2000} rows={2} placeholder={`Message ${otherParty}…`} value={draft} onChange={(event) => setDraft(event.target.value)} /><button className="portal-primary" disabled={!draft.trim() || sending} aria-label="Send message">{sending ? "Sending…" : <><Send size={15}/> Send</>}</button></form>
    </>}
  </section>;
}

import axios from "axios";

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || "/api", headers: { "Content-Type": "application/json" } });
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("homecare-token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});
export const apiService = { get: (url, config) => api.get(url, config), post: (url, data, config) => api.post(url, data, config), put: (url, data, config) => api.put(url, data, config), patch: (url, data, config) => api.patch(url, data, config), delete: (url, config) => api.delete(url, config) };
export const mockApi = { login: async (data) => ({ data: { name: data.name || "Priya Sharma", role: data.role || "customer" } }), register: async (data) => ({ data: { name: data.name, role: data.role || "customer" } }), getProperties: async () => ({ data: [] }), createProperty: async (data) => ({ data }), getProfessionals: async () => ({ data: [] }), createBooking: async (data) => ({ data }), getBookings: async () => ({ data: [] }), updateBooking: async (id, data) => ({ data: { id, ...data } }), getMaintenance: async () => ({ data: [] }), getWarranties: async () => ({ data: [] }), getHomePassport: async () => ({ data: [] }), submitProblem: async (data) => ({ data }), getAIAssessment: async () => ({ data: {} }) };
export default api;
